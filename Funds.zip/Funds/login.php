<?php
session_start();
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="hod")
	{
		header("Location: hodmenu.php");
	}
	else if($_SESSION["type"]=="hos")
	{	
		header("Location: hosmenu.php");
	}
	else
	{
		header("Location: adminmenu.php");
	}	
}
include("header.php"); 
include("connection.php");
if(isset($_POST["uid"]) && isset($_POST["pwd"]))
{
	$result=mysql_query("SELECT * from users WHERE username='$_POST[uid]'");
	while($row=mysql_fetch_array($result))
	{
		$pwdmd5=$row["password"];
		$type=$row["usertype"];
	}
	if(md5($_POST["pwd"])==$pwdmd5)
	{
		$_SESSION["userid"]=$_POST["uid"];
		$_SESSION["type"]=$type;
		if($type=="hod")
		{
			header("Location: hodmenu.php");
		}
		else if($type=="hos")
		{	
			header("Location: hosmenu.php");
		}
		else
		{
			header("Location: adminmenu.php");
		}	
	}
	else
	{
		$failure="Login failed..Please try again..!!";
	}
}
?>

<section id="contents">
	<article class="post">
		<header class="postheader">
  			<h2><u>Login</u></h2>
  		</header>
  		<section class="entry">
  			<form action="login.php" method="post" class="form">
   				<p class="textfield">Username
        	   	<input name="uid" id="uid" value="" type="text">
	   			</p>
   				<p class="textfield">Password
       			<input name="pwd" id="pwd" value="" type="password">
   				</p>
 	  			<p><input name="submit" id="submit" src="images/submit.png" type="image"></p>
   				<?php echo $failure;?>
   				<div class="clear"></div>
			</form>
		</section>
	</article>
</section>

<?php include("footer.php"); ?>