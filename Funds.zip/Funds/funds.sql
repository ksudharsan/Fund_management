-- MySQL dump 10.13  Distrib 5.5.47, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: funds
-- ------------------------------------------------------
-- Server version	5.5.47-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `discipline`
--

DROP TABLE IF EXISTS `discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discipline` (
  `disci_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`disci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discipline`
--

LOCK TABLES `discipline` WRITE;
/*!40000 ALTER TABLE `discipline` DISABLE KEYS */;
INSERT INTO `discipline` VALUES (1,'Physics');
/*!40000 ALTER TABLE `discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equip_accheads`
--

DROP TABLE IF EXISTS `equip_accheads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equip_accheads` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equip_accheads`
--

LOCK TABLES `equip_accheads` WRITE;
/*!40000 ALTER TABLE `equip_accheads` DISABLE KEYS */;
INSERT INTO `equip_accheads` VALUES (1,'Actual Expenses Booked & Payment Done'),(2,'Actual Expenses Booked'),(3,'PO in process(CWIP)'),(4,'PO in process(Commitment)'),(5,'Indents in process'),(6,'Advance Paid but Expenses not booked');
/*!40000 ALTER TABLE `equip_accheads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equip_capitalheads`
--

DROP TABLE IF EXISTS `equip_capitalheads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equip_capitalheads` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equip_capitalheads`
--

LOCK TABLES `equip_capitalheads` WRITE;
/*!40000 ALTER TABLE `equip_capitalheads` DISABLE KEYS */;
INSERT INTO `equip_capitalheads` VALUES (1,'Equipments'),(2,'Furnitures & Fixtures'),(3,'Computers & Peripherals'),(4,'Software'),(5,'Books'),(6,'Others');
/*!40000 ALTER TABLE `equip_capitalheads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funddetails`
--

DROP TABLE IF EXISTS `funddetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funddetails` (
  `EntryDate` date DEFAULT NULL,
  `Particulars` varchar(2000) DEFAULT NULL,
  `Year` varchar(20) DEFAULT NULL,
  `Indentor` varchar(255) DEFAULT NULL,
  `Indent_no` int(11) DEFAULT NULL,
  `PO_no` int(11) DEFAULT NULL,
  `IndentAmt` int(11) DEFAULT NULL,
  `Amount` int(11) DEFAULT NULL,
  `Remarks` varchar(2000) DEFAULT NULL,
  `Budgettype` int(11) DEFAULT NULL,
  `Accheads` int(11) DEFAULT NULL,
  `Discipline` int(11) DEFAULT NULL,
  `Equip_captype` int(11) DEFAULT NULL,
  `Equip_exptype` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funddetails`
--

LOCK TABLES `funddetails` WRITE;
/*!40000 ALTER TABLE `funddetails` DISABLE KEYS */;
INSERT INTO `funddetails` VALUES ('2016-01-12','hjvkjhbj','2011-12','Sudharsan',6587,8909908,643458,656546,'Yo Bitch..!!',1,1,1,NULL,NULL),('2015-12-09','hjvkjhbj','2011-12','Sudharsan',6587,8909908,643458,656546,'Yo Bitch..!!',2,4,1,1,2),('2015-12-09','xilinx','2014-15','Priyanshu',12345,123,1234567,1234567,'You Jackass...!!',2,3,1,4,1);
/*!40000 ALTER TABLE `funddetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recur_accheads`
--

DROP TABLE IF EXISTS `recur_accheads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recur_accheads` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recur_accheads`
--

LOCK TABLES `recur_accheads` WRITE;
/*!40000 ALTER TABLE `recur_accheads` DISABLE KEYS */;
INSERT INTO `recur_accheads` VALUES (1,'Actual Expenses Booked & Payment Done'),(2,'PO in process'),(3,'Indents in process'),(4,'Advance Paid but Expenses not booked');
/*!40000 ALTER TABLE `recur_accheads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(100) DEFAULT NULL,
  `usertype` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('123','83ec45960b80c035a0068df1d9df5aa8','admin');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-02 23:08:52
