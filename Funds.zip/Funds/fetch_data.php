<?php
session_start(); 
include("connection.php");
if(isset($_POST['get_option']))
{
  $btype=$_POST['get_option'];
  //echo $btype;
  if($btype==2)
  {
?>

    <select name="cap_head">
    <option selected> Select The Capital Head </option>
    
    <?php
    $caphead=mysql_query("Select id,name from equip_capitalheads");
    while($row=mysql_fetch_array($caphead))
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    ?>
    
    </select>
    <select name="exptype">
    <option selected >Select The Expenditure Type</option>
    <option value=1>Carried Forward Expenditure 2014-15</option>
    <option value=2>Expenditure 2015-16</option>
    </select>

    <select name="eq_accheads">
    <option selected >Select The Accounting Head</option>
    
    <?php 
    $acchead=mysql_query("Select name,id from equip_accheads");
    while($row=mysql_fetch_array($acchead))
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    echo "</select>";
    ?>

  <?php
  }
  else if($btype==1)
  {
  ?>
    
    <select name="re_accheads">
    <option selected value="0">Select The Accounting Head</option>
    
    <?php 
    $acchead=mysql_query("Select name,id from recur_accheads");
    while($row=mysql_fetch_array($acchead))
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    ?>
    </select>
<?php
  }
  ?>
<br>
<br>
<table>
<tr>
  <td>Entry Date</td>
  <td><input type="date" name="entrydate"></td>
</tr>
<tr>
  <td>Particulars</td>
  <td><input type="text" name="particulars"></td>
</tr>
<tr>
  <td>Year</td>
  <td><input type="text" name="year"></td>
</tr>
<tr>
  <td>Indentor</td>
  <td><input type="text" name="indentor"></td>
</tr>
<tr>
  <td>Indent No</td>
  <td><input type="text" name="indentno"></td>
</tr>
<tr>
  <td>PO no</td>
  <td><input type="text" name="pono"></td>
</tr>
<tr>
  <td>Indent Amount</td>
  <td><input type="text" name="indentamt"></td>
</tr>
<tr>
  <td>Amount</td>
  <td><input type="text" name="amount"></td>
</tr>
<tr>
  <td>Remarks</td>
  <td><input type="text" name="remarks"></td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="submit">
<?php
}
?>