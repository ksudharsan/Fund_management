<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>
<h2>ADMIN MENU</h2>
<p><a href="adminadd.php">ADD DETAILS</a></p>
<p><a href="adminedit.php">EDIT DETAILS</a></p>
<p><a href="adminview.php">VIEW DETAILS</a></p>