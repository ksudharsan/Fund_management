<?php
session_start(); 
include("connection.php");
?>
<!doctype html>
<html>
<head>
<title>Fund Management System</title>
<link href="style.css" rel="stylesheet" type="text/css">

</head>
<body>
</html>