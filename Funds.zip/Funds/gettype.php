<?php
session_start(); 
include("session.php");
include("connection.php");
?>
<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>

<?php
if(isset($_POST['get_type']))
{
  $btype=$_POST['get_type'];
?>
<select name="type" onchange="fetch_next(this.value)">
<option selected>Select The Budget Type</option> 
<option value=1>Recurring Budget</option>
<option value=2>Equipment Budget</option>
</select>

<div id="acchead">
</div>
<?php
}
?>
</body>
</html>


	