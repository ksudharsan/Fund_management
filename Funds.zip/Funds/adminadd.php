<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");

if(isset($_POST['submit']))
{
   if($_POST['type']==1)
   {
      $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Indent_no,PO_no,IndentAmt,Amount,Remarks,Budgettype,Accheads,Discipline) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['indentno'].','.$_POST['pono'].','.$_POST['indentamt'].','.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['re_accheads'].','.$_POST['disci'].');';

      $res=mysql_query($q);
      if($res)
      {
          echo "Data Successfully Inserted..!!";
      }
      else
      {
          echo "Data Insertion Failed..Please Check the values Entered...!!";
      }
   }
   else
   {
      $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Indent_no,PO_no,IndentAmt,Amount,Remarks,Budgettype,Accheads,Discipline,Equip_captype,Equip_exptype) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['indentno'].','.$_POST['pono'].','.$_POST['indentamt'].','.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['eq_accheads'].','.$_POST['disci'].','.$_POST['cap_head'].','.$_POST['exptype'].');';

      $res=mysql_query($q);
      if($res)
      {
          echo "Data Successfully Inserted..!!";
      }
      else
      {
          echo "Data Insertion Failed..Please Check the values Entered...!!";
      }
   }
}

?>

<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gettype(val)
{
   $.ajax({
      type: 'post',
      url: 'gettype.php',
      data: {
        get_type: val
      },
      success: function (response) {
       document.getElementById("btype").innerHTML=response; 
     }
   });
}

function fetch_next(val)
{
   $.ajax({
     type: 'post',
     url: 'fetch_data.php',
     data: {
       get_option: val
     },
     success: function (response) {
       document.getElementById("acchead").innerHTML=response; 
     }
   });
}
function get_table(val)
{
   $.ajax({
     type: 'post',
     url: 'gettable.php',
     data: {
       val: val
     },
     success: function (response) {
       document.getElementById("showtable").innerHTML=response; 
     }
   });
}
</script>
</head>
<body>
<p><center>CHOOSE</center></p>
<form action="adminadd.php" method="post">
	 <center>
	   <div>
        <select name="disci" onchange="gettype(this.value)">
        <option selected >Select Discipline</option>
        <?php
            $query=mysql_query("select disci_id,name from discipline");
            while($row=mysql_fetch_array($query))
            {
              echo "<option value=".$row['disci_id'].">".$row['name']."</option>";
            }
        ?>
        </select>
        <div id="btype">
        </div>      
        
    </div>     
	 </center>
</form>
	  
   
   </body>
</html>