<?php
$con = mysql_connect("localhost","root","");
if (!$con)
{
	die('Could not connect: ' . mysql_error());
}
mysql_select_db("funds", $con);
if (!$con)
{
	die('Could not Select Database: ' . mysql_error());
}
?>
