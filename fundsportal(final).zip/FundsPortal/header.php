<?php
session_start(); 
include("connection.php");
?>
<!doctype html>
<html>
<head>
<title>Fund Management System</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="titlebar">
<a href="login.php">
<img class="logo" src="images/logo.png"></img></a>
<div class="title">FUND MANAGEMENT PORTAL</div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	function refunction()
	{
		window.location.assign("adminmenu.php");
	}
</script>
<?php
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="admin")
	{
		?>
		<div class="dropdown">
		  <button class="dropbtn" onclick="refunction();">ADMIN MENU</button>
		  <div class="dropdown-content">
		    <a href="adminadd.php">Add Details</a>
		    <a href="adminedit.php">Edit Details</a>
		    <a href="adminview.php">View Details</a>
		    <a href="summary.php">View Summary</a>
		    <a href="addhead.php">Add Head</a>
		    <a href="adminacc.php">Manage Users</a>
		    <a href="adminest.php">Update Estimate</a>
		    <a href="addcaphead.php">Add Capital Head</a>
		    <a href="curryear.php">Change Current Year</a>
		  </div>
		</div>
		<?php
	}
	?>
	<div class="dropdown1">
	  <button class="dropbtn1">Hi <?php echo $_SESSION["userid"]; ?>..!!</button>
	  <div class="dropdown1-content">
	    <a href="logout.php">LOGOUT</a>
	  </div>
	</div>
	<?php
}
?>
</body>
</html>