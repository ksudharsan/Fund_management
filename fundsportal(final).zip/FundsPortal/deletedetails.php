<?php
include("connection.php");
if(isset($_POST['sno']))
{
	$q='delete from funddetails where SNo="'.$_POST["sno"].'"';
	$res=$conn->query($q);
	if($res)
	{

	}
	else
	{
		alert("Data Could not be Deleted..!!");
		header("Location: adminedit.php");
	}
}
else 
{
    header("Location:login.php");
}
?>