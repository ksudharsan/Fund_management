<?php
session_start();
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]!="admin")header("Location: login.php");
}
else
{
	header("Location: login.php");
}
?>