<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	function myfunction(val)
	{
		var x=confirm("Are You Sure You Want to Enter A New Financial Year..?? You Can't Undo this Action.");
		if(x==true)
		{
			$.ajax({
	     	type: 'post',
	     	url: 'chcurryear.php',
	     	data: {
	    	   username: val
	    	 },
	    	success: function (response) {
	    			alert("Welcome To A New Financial Year..!!"),
	         		window.location.assign("adminmenu.php")
	         		//getElementById('qwerty').innerHTML=response;
	         		//alert(response);
	     		}
	   		});
		}
		else return false;
	}
</script>
<?php
if(isset($_POST["uid"]))
{
	if($_POST["uid"]!="" && isset($_POST["uid"]))
	{
		?>
		<script>
		myfunction("<?php echo $_POST["uid"]; ?>");
		</script>
		<?php 
	}
	else
	{
		?>
		<p class="chpass_err">Please Enter A Year.</p>
		<?php
	}
}
?>

<img class="addimg" src="images/addimg.png"></img>
<h2 class="curryear">CHANGE CURRENT YEAR</h2>
<form action="curryear.php" method="post">
<p class="ch_uname">Please Enter The New FY</p>
<input class="chpass_uname" id="uid" name="uid" type="text">
<input class="chpass_sub" name="submit" type="image" src="images/submit.png"> 
</form>
<div id="qwerty"></div>
<script type="text/javascript">
  <?php if(isset($_POST["uid"])) {?>document.getElementById('uid').value = "<?php echo $_POST["uid"];?>";<?php } ?>
</script>