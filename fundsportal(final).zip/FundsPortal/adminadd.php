<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");

if(isset($_POST["submit"]))
{
   $RE0=$conn->query("select * from years where name='curryear'; ");
   while($row0=$RE0->fetch_assoc())
   {
     $curryear=$row0['val'];
   }
   if($_POST["type"]==1)
   {
        if($_POST["indenttype"]==1)
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Indent_no,PO_no,IndentAmt,Amount,Remarks,Budgettype,Accheads,Discipline,IndentType,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['indentno'].','.$_POST['pono'].','.$_POST['indentamt'].','.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['re_accheads'].','.$_POST['disci'].','.$_POST["indenttype"].',"'.$curryear.'");';
            //echo $q;
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        }
        else if($_POST["indenttype"]==4)
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Amount,Remarks,Budgettype,Accheads,Discipline,IndentType,IndentVal,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['re_accheads'].','.$_POST['disci'].','.$_POST["indenttype"].',"'.$_POST["otherindent"].'","'.$curryear.'");';
            //echo $q;
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        } 
        else
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Amount,Remarks,Budgettype,Accheads,Discipline,IndentType,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['re_accheads'].','.$_POST['disci'].','.$_POST["indenttype"].',"'.$curryear.'");';
            //echo $q;
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        }
    }
    else
    {
        if($_POST["indenttype"]==1)
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Indent_no,PO_no,IndentAmt,Amount,Remarks,Budgettype,Accheads,Discipline,Equip_captype,Equip_exptype,IndentType,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['indentno'].','.$_POST['pono'].','.$_POST['indentamt'].','.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['eq_accheads'].','.$_POST['disci'].','.$_POST['cap_head'].','.$_POST['exptype'].','.$_POST["indenttype"].',"'.$curryear.'");';
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        }
        else if($_POST["indenttype"]==4)
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Amount,Remarks,Budgettype,Accheads,Discipline,Equip_captype,Equip_exptype,IndentType,IndentVal,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['eq_accheads'].','.$_POST['disci'].','.$_POST['cap_head'].','.$_POST['exptype'].','.$_POST["indenttype"].',"'.$_POST["otherindent"].'","'.$curryear.'");';
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        } 
        else
        {
            $q='insert into funddetails(EntryDate,Particulars,Year,Indentor,Amount,Remarks,Budgettype,Accheads,Discipline,Equip_captype,Equip_exptype,IndentType,FY) values ("'.$_POST['entrydate'].'","'.$_POST['particulars'].'","'.$_POST['year'].'","'.$_POST['indentor'].'",'.$_POST['amount'].',"'.$_POST['remarks'].'",'.$_POST['type'].','.$_POST['eq_accheads'].','.$_POST['disci'].','.$_POST['cap_head'].','.$_POST['exptype'].','.$_POST["indenttype"].',"'.$curryear.'");';
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Inserted..!!");
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Insertion Failed. Please Check The Values and TRY AGAIN..!!");
                </script>
                <?php
            }
        }
   }
}

?>

<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gettype(val)
{
   $.ajax({
      type: 'post',
      url: 'gettype.php',
      data: {
        get_type: val
      },
      success: function (response) {
       document.getElementById("btype").innerHTML=response; 
     }
   });
}

function fetch_next(val)
{
   $.ajax({
     type: 'post',
     url: 'fetch_data.php',
     data: {
       get_option: val
     },
     success: function (response) {
       document.getElementById("acchead").innerHTML=response; 
     }
   });
}
function indtype(val)
{
   $.ajax({
     type: 'post',
     url: 'getindent.php',
     data: {
       indenttype: val
     },
     success: function (response) {
       document.getElementById("ind").innerHTML=response; 
     }
   });
}
</script>
</head>
<body>

<h2 class="choose">CHOOSE</h2>
<form action="adminadd.php" method="post">
        
        <select class="type" name="type" onchange="gettype(this.value)">
            <option selected>Select The Budget Type</option> 
            <option value=1>Recurring Budget</option>
            <option value=2>Equipment Budget</option>
        </select>

        <div id="btype">
        </div>   
    </div>     
</form>
	  
   
   </body>
</html>