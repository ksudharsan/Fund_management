<?php
include("connection.php");

if(isset($_POST["username"]))
{
	$q='delete from users where username="'.$_POST["username"].'" ';
	$res=$conn->query($q);
}
?>