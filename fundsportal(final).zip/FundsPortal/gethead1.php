<?php
include("connection.php");

if(isset($_POST['gethead']))
{
    if($_POST['gethead']==1)
    {
        $res=$conn->query("select id,name from recur_heads;");
        while($row=$res->fetch_assoc())
        {
            ?>
            <option value="<?php echo $row['id']; ?>" <?php if($row['id']==$_POST["disci1"]) echo "selected" ?> > <?php echo $row['name']; ?> </option>;
            <?php
        }
    } 
    else if($_POST['gethead']==2)
    {
        $res=$conn->query("select id,name from equip_heads;");
        while($row=$res->fetch_assoc())
        {
            ?>
            <option value="<?php echo $row['id']; ?>" <?php if($row['id']==$_POST["disci1"]) echo "selected" ?> > <?php echo $row['name']; ?> </option>;
            <?php
        }
    }
    else
    {
        ?>
        <option value=0 selected>Select Head</option>
        <?php
    }
}
else 
{
    header("Location:login.php");
}
?>