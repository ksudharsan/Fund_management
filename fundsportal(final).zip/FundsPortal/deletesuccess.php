<?php
include("connection.php");
echo "success";
?>