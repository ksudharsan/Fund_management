<?php
include("connection.php");

if(isset($_POST["username"]))
{
	$q='select * from years where name="curryear" ;';
	$res=$conn->query($q);
	while($row=$res->fetch_assoc())
	{
		$curr=$row['val'];
		$prev=$row['prev'];
	}
	$q1='update years set name=NULL where name="curryear" ;';
	$res1=$conn->query($q1);
	$q2='insert into years values("curryear","'.$_POST["username"].'","'.$curr.'") ;';
	$res2=$conn->query($q2);

}
else
{
	header("Location: login.php");
}
?>