<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>

<img class="outimg" src="images/addfailure.jpg"></img>
<a href="adminedit.php"><img class="back" src="images/back.png"></img><div>BACK</div></a>
<div class="output1">Data Updation Failed.</div>
<div class="output2">Please Check the values Entered.</div>
