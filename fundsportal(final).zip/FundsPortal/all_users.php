<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>
<table class="users">
<tr>
	<th class="users">User Name</th>
	<th class="users">User Type</th>
	<th class="users"></th>
	<th class="users">Description</th>
</tr>
<?php
$res=$conn->query("select * from users;");
while($row=$res->fetch_assoc())
{
?>
	<tr>
		<td class="users"><?php echo $row['username']; ?></td>
		<td class="users">
		<?php 
			if($row['usertype']=='hos')
			{
				echo "Head Of School";
			}
			else if($row['usertype']=='hod')
			{
				echo "Head Of Department";
			}
			else if($row['usertype']=='admin')
			{
				echo "ADMIN";
			}
			else
			{
				echo "ADMIN(View ONLY)";
			}
		?>
		</td>
		<td class="users">
		<?php 
			if($row['usertype']=='hos')
			{
				$q1='select * from school where school_id='.$row['id_val'].';';
				$res1=$conn->query($q1);
				while($row1=$res1->fetch_assoc())
				{
					echo $row1['name'];
				}
			}
			else if($row['usertype']=='hod')
			{
				$q1='select * from discipline where disci_id='.$row['id_val'].';';
				$res1=$conn->query($q1);
				while($row1=$res1->fetch_assoc())
				{
					echo $row1['name'];
				}
			}
		?>
		</td>
		<td class="descrip">
		<?php 
			if($row['usertype']=='hos')
			{
				echo "Has Previleges To See Details Of all Departments Under his School.";
			}
			else if($row['usertype']=='hod')
			{
				echo "Has Previleges To See Details Of his Department.";
			}
			else if($row['usertype']=='admin')
			{
				echo "Has Ultimate Previleges to ADD,EDIT and UPDATE all details.";
			}
			else
			{
				echo "Has Previleges to VIEW details of all School/Departments.";				
			}
		?>
		</td>
	</tr>
<?php 
}
?>
</table>
<h2 class="users">USER DETAILS</h2>