<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>

<h2>MANAGE USERS</h2>
<a href="add_user.php"><img class="add_user" src="images/add_user.png"></img></a>
<a href="change_pass.php"><img class="change_pass" src="images/change_pass.png"></img></a>
<a href="all_users.php"><img class="all_users" src="images/all_users.png"></img></a>
<a href="delete_users.php"><img class="delete_users" src="images/delete_users.png"></img></a>

<p class="add_user">ADD USER</p>
<p class="change_pass">CHANGE PASSWORD</p>
<p class="all_users">VIEW ALL USERS</p>
<p class="delete_users">DELETE USERS</p>