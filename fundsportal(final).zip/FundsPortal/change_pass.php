<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>
<form action="change_pass.php" method="post">
<?php
if(isset($_POST["uid"]) && isset($_POST["pwd"]))
{
	if($_POST["pwd"]=="")
	{
		?>
		<p class="chpass_err">Please Enter A Password.</p>
		<?php
	}
	else if($_POST["pwd"]==$_POST["pwd1"])
	{
		$passw=md5($_POST["pwd"]);
		$que='update users set password="'.$passw.'" where username="'.$_POST["uid"].'";';
		$result=$conn->query($que);
		if($result)
		{
			?>
			<script>alert("Password Successfully Changed..!")</script>
			<!-- <p class="adderr">User Successfully Added..!</p> -->
			<?php
		}
		else
		{
			?>
			<script>alert("Please Check The Details..!")</script>
			<!-- <p class="adderr">Please Check The Details..!</p> -->
			<?php
		}
	}
	else
	{
		?>
		<script>
		alert("Passwords Did Not Match..!!");
		</script>
		<?php
	}
}
else if(isset($_POST["uid"]))
{
	if($_POST["uid"]!="" && isset($_POST["uid"]))
	{
		$q1='select * from users where username="'.$_POST["uid"].'";';
		$res=$conn->query($q1);	
		if(mysqli_num_rows($res))
		{
			$flag++;
			?>

			<p class="newpass">Enter New Password</p>
			<input class="newpass" id="pwd" name="pwd" type="password">
			<p class="newpass1">Retype-Password</p>
			<input class="newpass1" id="pwd1" name="pwd1" type="password">
			<?php 
		}
		else
		{
			?>
			<p class="chpass_err">No Such User Found.</p>
			<?php
		}
	}
	else
	{
		?>
		<p class="chpass_err">Please Enter A Username.</p>
		<?php
	}
}
?>
<img class="addimg" src="images/addimg.png"></img>
<h2 class="chpass">Change Password</h2>
<p class="ch_uname">Please Enter The Username</p>
<div id="set"></div>
<input class="chpass_uname" id="uid" name="uid" type="text">
<?php if($flag>0) { ?><input class="chpass_sub1" name="submit" type="image" src="images/submit.png"> <?php } else { ?> <input class="chpass_sub" name="submit" type="image" src="images/submit.png"><?php } ?>
</form>
<script type="text/javascript">
  <?php if(isset($_POST["uid"])) {?>document.getElementById('uid').value = "<?php echo $_POST["uid"];?>";<?php } ?>
</script>