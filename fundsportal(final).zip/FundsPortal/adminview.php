<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");

function moneyFormatIndia($num){
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){
            // creates each of the 2's group and adds a comma to the end
            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}


if($_POST["fy"]!=0)
{
	if($_POST["type"]==1 && $_POST["disci"]!=0)
	{
	?> 
		<table class="detail">
		<tr>
			<th class="head" colspan="8">CONSUMABLES & CONTINGENCIES (
				<?php 
					$RE1=$conn->query("select * from recur_heads where id=".$_POST["disci"]."; ");
					while($row3=$RE1->fetch_assoc())
					{
						echo $row3['name'];
					}
				?> 
			)</th>
		</tr>
		<tr>
			<th class="tot" colspan="8">Revised Estimate</th>
			<td class="detail">
				<?php 
					$RE=$conn->query("select * from est_val where Budgettype=".$_POST["type"]." and Disci_id=".$_POST["disci"]." and FY='".$_POST["fy"]."'; ");
					$f=0;
					while($row2=$RE->fetch_assoc())
					{
						echo moneyFormatIndia($row2['Revised_Est']);
						$f=1;
						$revised=$row2['Revised_Est'];
					}
					if($f==0)echo "-";
				?>
			</td>
		</tr>
		<?php
		$gtotal=0;
	    $res=$conn->query("select * from recur_accheads;");
	    while($row=$res->fetch_assoc())
	    {
	    ?>
	    	<tr><th class="head" colspan="8">
	  		<?php echo $row['name']; ?>
	    	</th></tr>
			<tr>
				<th class="detail">Entry Date</th>
				<th class="detail">Particulars</th>
				<th class="detail">Year</th>
				<th class="detail">Indentor</th>
				<th class="detail">Indent No</th>
				<th class="detail">PO no</th>
				<th class="detail">Indent Amt</th>
				<th class="detail">Amount</th>
				<th class="detail">Remarks</th>
			</tr>
			<?php
			$total=0;
			if($_POST["filter"]==true)
			$qe1='select * from funddetails where Budgettype=1 and Discipline='.$_POST["disci"].' and Accheads='.$row['id'].' and Indentor="'.$_POST["filterval"].'" and FY="'.$_POST["fy"].'" ';
			else
			$qe1='select * from funddetails where Budgettype=1 and Discipline='.$_POST["disci"].' and Accheads='.$row['id'].' and FY="'.$_POST["fy"].'"  ';
			?>
			<?php
			$res1=$conn->query($qe1); 
			while($row1=$res1->fetch_assoc())
			{
			?>
				<tr>
					<td class="detail"><?php echo date("d-m-Y",strtotime($row1['EntryDate'])); ?></td>
					<td class="detail"><?php echo $row1['Particulars']; ?></td>
					<td class="detail"><?php echo $row1['Year']; ?></td>
					<td class="detail"><?php echo $row1['Indentor']; ?></td>
					<?php
						if($row1['IndentType']==1)
						{
							?>
							<td class="detail"><?php echo $row1['Indent_no']; ?></td>
							<td class="detail"><?php echo $row1['PO_no']; ?></td>
							<td class="detail"><?php echo moneyFormatIndia($row1['IndentAmt']); ?></td>
							<?php
						} 
						else if($row1['IndentType']==2)
						{
							?>
							<td class="detail" colspan="3">Direct Purchase</td>
							<?php
						}
						else if($row1['IndentType']==3)
						{
							?>
							<td class="detail" colspan="3">Direct Purchase(Through Advance)</td>
							<?php
						}
						else 
						{
							?>
							<td class="detail" colspan="3"><?php echo $row1['IndentVal']; ?></td>
							<?php
						}
					?>
					
					<td class="detail"><?php echo moneyFormatIndia($row1['Amount']);  $total+=$row1['Amount'] ?></td>
					<td class="detail"><?php echo $row1['Remarks']; ?></td>
				</tr>

			<?php
			}
			?>
			<tr>
				<th class="tot" colspan="7">Total</th>
				<td class="detail"><?php echo moneyFormatIndia($total); $gtotal+=$total;?></td>
			</tr>
		<?php 
	    } ?>
	    <tr>
			<th class="tot" colspan="8">Grand Total</th>
			<td class="detail"><?php echo moneyFormatIndia($gtotal); ?></td>
		</tr>
		 <tr>
			<th class="tot" colspan="8">Grand Total in Lakhs</th>
			<td class="detail"><?php echo round($gtotal/100000.0,2); ?></td>
		</tr>
		<tr>
			<th class="tot" colspan="8">Net Balance</th>
			<td class="detail"><?php echo moneyFormatIndia($revised-$gtotal); ?></td>
		</tr>
		</table>

	<?php	
	}
	else if($_POST["type"]==2 && $_POST["disci"]!=0)
	{
		?>
		<table class="detail">
		<col span="1" class="wide">
		<tr>
			<th class="head" colspan="8">EQUIPMENT BUDGET (
				<?php 
					$RE1=$conn->query("select * from equip_heads where id=".$_POST["disci"]."; ");
					while($row1=$RE1->fetch_assoc())
					{
						echo $row1['name'];
					}
				?> 
			)</th>
		</tr>
		<tr>
			<th class="detail2">ACCOUNT HEADS</th>
				<?php
					$RE2=$conn->query("select * from equip_capitalheads ; ");
					while($row2=$RE2->fetch_assoc())
					{
						?>
						<th class="detail2"><?php echo $row2['name']; ?></th>
						<?php
					}
				?> 
			</th>
			<th class="detail2">TOTAL</th>
		</tr>
		<tr>
			<th class="detail3">1. Revised Estimate (in lakhs)</th>
			<?php
				$RES0=$conn->query("select max(id) as maxi from equip_capitalheads;");
				while($rows0=$RES0->fetch_assoc())
				{
					$maxid=$rows0['maxi'];
				}
			?>
			<td class="detail" colspan="<?php echo $maxid; ?>"></td>
			<td class="detail">
				<?php
					$RE3=$conn->query("select Revised_Est from est_val where Budgettype=".$_POST["type"]." and Disci_id=".$_POST["disci"]." and FY='".$_POST["fy"]."' ; ");
					while($row3=$RE3->fetch_assoc())
					{
						echo round($row3['Revised_Est']/100000.0,2);
						$rev=$row3['Revised_Est'];
					}
				?> 
			</td>
		</tr>
		<tr>
			<th class="detail3">2. Carried Forward Expenditure (in lakhs)</th>
			
		</tr>
		<!-- <tr> -->
		<?php
			$RE4=$conn->query("select * from equip_accheads;");
			while($row4=$RE4->fetch_assoc())
			{
				?>
				<tr>
		
					<td class="detail3"><?php echo '('; echo chr($row4['id']+96); echo ') '; echo $row4['name']; ?></td>
					<?php
					for($caphead=1;$caphead<=$maxid;$caphead++)
					{
						$RE5=$conn->query("select sum(Amount) from funddetails where Budgettype=2 and Equip_exptype=1 and Accheads=".$row4['id']." and Discipline=".$_POST["disci"]." and Equip_captype=".$caphead." and FY='".$_POST["fy"]."' ; ");
						while($row5=$RE5->fetch_assoc())
						{
							?>
							<td class="detail"><?php echo round($row5['sum(Amount)']/100000.0,2); ?></td>
							<?php
						}
					}
					?>
		
				</tr>
				<?php
			}
		?>
		<tr>
			<th class="tot2">TOTAL[2 (a)+(b)+(c)+(d)+(e)+(f)]</th>
			<?php
			$tot=0;
			for($caphead=1;$caphead<=$maxid;$caphead++)
			{
				$RE6=$conn->query("select sum(Amount) from funddetails where Budgettype=2 and Equip_exptype=1 and Discipline=".$_POST["disci"]." and Equip_captype=".$caphead." and FY='".$_POST["fy"]."'; ");
				while($row6=$RE6->fetch_assoc())
				{
					?>
					<td class="detail"><?php echo round($row6['sum(Amount)']/100000.0,2); $tot+=$row6['sum(Amount)']; ?></td>
					<?php
				}
			}
			?>
			<td class="detail"><?php echo round($tot/100000.0,2); ?></td>
		</tr>

		<tr>
			<th class="detail3">3. Expenditure (in lakhs)</th>
		</tr>
		<!-- <tr> -->
		<?php
			$RE4=$conn->query("select * from equip_accheads;");
			while($row4=$RE4->fetch_assoc())
			{
				?>
				<tr>
		
					<td class="detail3"><?php echo '('; echo chr($row4['id']+96); echo ') '; echo $row4['name']; ?></td>
					<?php
					for($caphead=1;$caphead<=$maxid;$caphead++)
					{
						$RE5=$conn->query("select sum(Amount) from funddetails where Budgettype=2 and Equip_exptype=2 and Accheads=".$row4['id']." and Discipline=".$_POST["disci"]." and Equip_captype=".$caphead." and FY='".$_POST["fy"]."'; ");
						while($row5=$RE5->fetch_assoc())
						{
							?>
							<td class="detail"><?php echo round($row5['sum(Amount)']/100000.0,2); ?></td>
							<?php
						}
					}
					?>
		
				</tr>
				<?php
			}
		?>
		<tr>
			<th class="tot2">TOTAL[3 (a)+(b)+(c)+(d)+(e)+(f)]</th>
			<?php
			$tot2=0;
			for($caphead=1;$caphead<=$maxid;$caphead++)
			{
				$RE6=$conn->query("select sum(Amount) from funddetails where Budgettype=2 and Equip_exptype=2 and Discipline=".$_POST["disci"]." and Equip_captype=".$caphead." and FY='".$_POST["fy"]."' ; ");
				while($row6=$RE6->fetch_assoc())
				{
					?>
					<td class="detail"><?php echo round($row6['sum(Amount)']/100000.0,2); $tot2+=$row6['sum(Amount)']; ?></td>
					<?php
				}
			}
			?>
			<td class="detail"><?php echo round($tot2/100000.0,2); ?></td>
		</tr>
		<tr>
			<th class="detail3">4. Net Balance available after Carried Forward Expenditure (in lakhs) [1-2-3]</th>
			<td class="tot3" colspan="<?php echo $maxid+1;?>"><?php echo round(($rev-$tot-$tot2)/100000.0,2);?></td>
		</tr>
		<tr>
			<th class="detail3">5. Net Balance available before Carried Forward Expenditure (in lakhs) [1-3]</th>
			<td class="tot3" colspan="<?php echo $maxid+1;?>"><?php echo round(($rev-$tot2)/100000.0,2);?></td>
		</tr>
		</table>

		<table class="detailnext">
		<tr>
			<th class="smallcenter" colspan="8">DETAILED EXPENDITURE SHEET</th>
		</tr>
		<tr>
			<th class="tot" colspan="8">Revised Estimate</th>
			<td class="detail">
				<?php 
					$RE1=$conn->query("select * from est_val where Budgettype=".$_POST["type"]." and Disci_id=".$_POST["disci"]." and FY='".$_POST["fy"]."'; ");
					$f=0;
					while($row1=$RE1->fetch_assoc())
					{
						echo moneyFormatIndia($row1['Revised_Est']);
						$f=1;
						$revised=$row1['Revised_Est'];
					}
					if($f==0)echo "-";
				?>
			</td>
		</tr>
		<?php
			$RE2=$conn->query("select * from equip_capitalheads;");
			while($row2=$RE2->fetch_assoc())
			{
				?>
				<tr>
					<th class="smallcenter" bgcolor="green" colspan="8"><?php echo '('; echo chr($row2['id']+64); echo ')'; echo $row2['name']; ?></th> 
				</tr>
				<?php
					for($exptype=1;$exptype<=2;$exptype++)
					{
						?>
						<tr>
							<th class="smallcenter" bgcolor="green" colspan="8">
								<?php
									echo $exptype+1;
									echo '. ';
									if($exptype==1)echo 'Carried Forward Expenditure';
									else echo 'Expenditure';
								?>
							</th> 				
						</tr>


						<?php
							$gtotal=0;
						    $RE3=$conn->query("select * from equip_accheads;");
						    while($row3=$RE3->fetch_assoc())
						    {
						    ?>
						    	<tr><th class="smallcenter" bgcolor="white" colspan="8">
						  		<?php echo $exptype+1; echo '. '; echo '('; echo chr($row3['id']+96); echo ') '; echo $row3['name']; ?>
						    	</th></tr>
								<tr>
									<th class="detailnext">Entry Date</th>
									<th class="detailnext">Particulars</th>
									<th class="detailnext">Year</th>
									<th class="detailnext">Indentor</th>
									<th class="detailnext">Indent No</th>
									<th class="detailnext">PO no</th>
									<th class="detailnext">Indent Amt</th>
									<th class="detailnext">Amount</th>
									<th class="detailnext">Remarks</th>
								</tr>
								<?php
								$total=0;
								if($_POST["filter"]==true)
									$qe4='select * from funddetails where Budgettype=2 and Discipline='.$_POST["disci"].' and Accheads='.$row3['id'].' and Equip_captype='.$row2['id'].' and Equip_exptype='.$exptype.' and Indentor="'.$_POST["filterval"].'" and FY="'.$_POST["fy"].'" ';
								else
									$qe4='select * from funddetails where Budgettype=2 and Discipline='.$_POST["disci"].' and Accheads='.$row3['id'].' and Equip_captype='.$row2['id'].' and Equip_exptype='.$exptype.' and FY="'.$_POST["fy"].'" ';
								$RE4=$conn->query($qe4); 
								while($row4=$RE4->fetch_assoc())
								{
								?>
									<tr>
										<td class="detail"><?php echo date("d-m-Y",strtotime($row4['EntryDate'])); ?></td>
										<td class="detail"><?php echo $row4['Particulars']; ?></td>
										<td class="detail"><?php echo $row4['Year']; ?></td>
										<td class="detail"><?php echo $row4['Indentor']; ?></td>
										<?php
											if($row4['IndentType']==1)
											{
												?>
												<td class="detail"><?php echo $row4['Indent_no']; ?></td>
												<td class="detail"><?php echo $row4['PO_no']; ?></td>
												<td class="detail"><?php echo moneyFormatIndia($row4['IndentAmt']); ?></td>
												<?php
											} 
											else if($row4['IndentType']==2)
											{
												?>
												<td class="detail" colspan="3">Direct Purchase</td>
												<?php
											}
											else if($row4['IndentType']==3)
											{
												?>
												<td class="detail" colspan="3">Direct Purchase(Through Advance)</td>
												<?php
											}
											else 
											{
												?>
												<td class="detail" colspan="3"><?php echo $row4['IndentVal']; ?></td>
												<?php
											}
										?>
										
										<td class="detail"><?php echo moneyFormatIndia($row4['Amount']);  $total+=$row4['Amount'] ?></td>
										<td class="detail"><?php echo $row4['Remarks']; ?></td>
									</tr>

								<?php
								}
								?>
								<tr>
									<th class="tot" colspan="7">Total <?php echo $exptype+1; echo '. '; echo '('; echo chr($row3['id']+96); echo ') '; ?></th>
									<td class="detail"><?php echo moneyFormatIndia($total); ?></td>
								</tr>
							
							<?php 
						    } ?>

						<?php
					}
			}
		?>
		</table>
		<?php
	}
}
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gethead(val1,val2)
{
   $.ajax({
      type: 'post',
      url: 'gethead.php',
      data: {
        gethead: val1,
        disci1: val2
      },
      success: function (response) {
       document.getElementById("disci").innerHTML=response; 
     }
   });
}
function indentfilter(val)
{
   	if(val.checked == true || val=="on"){
   		document.getElementById('filterinput').style.visibility='visible';
   	}
  	else{
  		document.getElementById('filterinput').style.visibility='hidden';
  	}
}
</script>


<h2 class="choose1">CHOOSE</h2>
<form>
<input type="button" class="print" value="PRINT" onClick="window.print()">
</form>
<form action="adminview.php" method="post">
<select class="fy" name="fy" id="fy">
<option value=0>Select The FY</option> 
	<?php
		$RE0=$conn->query("select distinct(FY) as fy from funddetails;");
		while($row0=$RE0->fetch_assoc())
		{
			?>
			<option id="<?php echo $row0['fy']; ?>"><?php echo $row0['fy']; ?></option>
			<?php
		}
	?>
</select>
<select class="type1" name="type" id="type" onchange="gethead(this.value,0)">
<option value=0>Select The Budget Type</option> 
<option value=1>Recurring Budget</option>
<option value=2>Equipment Budget</option>
</select>
<p class="filter">Filter By</p>
<input type="checkbox" id="filter" name="filter" class="check" onchange="indentfilter(this)"/>
<input type="input" id="filterinput" class="inputfilter" name="filterval" style="visibility:hidden"/>
<p class="indentfilter">Indentor</p>
<select class="disci1" name="disci" id="disci">
  <option value=0>Select Head</option>
 </select>
 <input name="submit" class="submit1" src="images/submit.png" type="image">
 </form>
 <script type="text/javascript">
  <?php if($_POST["fy"]!=0){ ?> document.getElementById('fy').value= "<?php echo $_POST["fy"]; ?>"; <?php } ?>
  <?php if(isset($_POST["type"]) && $_POST["type"]!=0) {?>document.getElementById('type').value = "<?php echo $_POST["type"];?>"; gethead(<?php echo $_POST["type"]; ?>,<?php echo $_POST["disci"];?>); <?php } ?>
  indentfilter("<?php echo $_POST["filter"]; ?>");
  <?php if($_POST["filter"]==true){ ?>document.getElementById('filter').checked = true; <?php } ?>
  <?php if($_POST["filter"]==true){?>document.getElementById('filterinput').value="<?php echo $_POST["filterval"]; ?>" <?php  } ?>

</script>