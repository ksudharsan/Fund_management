<?php
if($_POST['indenttype']==1)
  {
      ?>
      <table class="ind0">
        <tr class="tabs">
          <td class="tabs">Indent No</td>
          <td class="tabs"><input class="tabs" type="text" name="indentno" value="<?php echo $_POST['indentno']; ?>" ></td>
        </tr>
        <tr class="tabs">
          <td class="tabs">PO no</td>
          <td class="tabs"><input class="tabs" type="text" name="pono" value="<?php echo $_POST['pono']; ?>" ></td>
        </tr>
        <tr class="tabs">
          <td class="tabs">Indent Amount</td>
          <td class="tabs"><input class="tabs" type="text" name="indentamt" value="<?php echo $_POST['indentamt']; ?>" ></td>
        </tr>
        </table>
      <?php
  }
  else if($_POST["indenttype"]==4)
  {
      ?>
      <table class="ind1">
      <tr class="tabs">
        <td class="tabs">Details</td>
        <td class="tabs"><input class="tabs" type="text" name="otherindent" value="<?php echo $_POST['indentval']; ?>" ></td>
      </tr>
      </table>
      <?php
  }
  else 
{
    die();
}
?>