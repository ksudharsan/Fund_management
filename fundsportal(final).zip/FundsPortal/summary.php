<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");

function moneyFormatIndia($num){
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){
            // creates each of the 2's group and adds a comma to the end
            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}

if($_POST["fy"]!=0)
{
	if($_POST["type"]==1 && $_POST["disci"]!=0)
	{
	?> 
		<table class="detail">
		<col span="1" class="coldet">
		<tr>
			<th class="head" colspan="9">Summary Of Recurring Budget</th>
		</tr>
		<tr>
			<th class="detailcol1">Accounting Heads</th>
			<th class="detail">Revised Estimate</th>
			<?php 
				$RE1=$conn->query("select * from recur_accheads;");
				while($row1=$RE1->fetch_assoc())
				{
					?>
					<th class="detail"><?php echo $row1['name']; ?></th>
					<?php
				}
			?>
			<th  class="detail">Total Commitments</th>
			<th  class="detail">Total Expenses including Commitments</th>
			<th class="detail">Net Balance</th>
		</tr>
		<tr>
			<th class="detail"></th>
			<th class="detail">[A]</th>
			<th class="detail">[B]</th>
			<th class="detail">[C]</th>
			<th class="detail">[D]</th>
			<th class="detail">[E]</th>
			<th class="detail">[F]=[C]+[D]</th>
			<th class="detail">[G]=[B]+[E]+[F]</th>
			<th class="detail">[H]=[A]-[G]</th>
		</tr>
		<tr>
			<th class="detailcol1">Consumables & Contingency:</th>
		</tr>
		<?php
			$RE2=$conn->query("select * from recur_heads;");
			while($row2=$RE2->fetch_assoc())
			{
				?>
				<tr>
				<th class="detail2"><?php echo $row2['name']; ?></th>
				<?php
				$val=[];
				$f=0;
				$RE3=$conn->query("select * from est_val where Budgettype=1 and Disci_id=".$row2['id']." and FY='".$_POST["fy"]."'  ; ");
				while($row3=$RE3->fetch_assoc())
				{
					?>
					<td class="tot2"><?php $f=1;$val[1]=$row3['Revised_Est']; echo moneyFormatIndia($row3['Revised_Est']); ?></td>
					<?php
				}
				if($f==0){?><td class="tot2">-</td><?php }
				for($accid=1;$accid<=4;$accid++)
				{
					//echo "select sum(Amount) as totsum from funddetails where Budgettype=1 and Disci_id=".$row2['id']." and Accheads=".$accid."; ";
					$RE3=$conn->query("select sum(Amount) as totsum from funddetails where Budgettype=1 and Discipline=".$row2['id']." and Accheads=".$accid." and FY='".$_POST["fy"]."' ; ");
					while($row3=$RE3->fetch_assoc())
					{
						?>
						<td class="tot2"><?php $val[$accid+1]=$row3['totsum']; if($row3['totsum']!=NULL)echo moneyFormatIndia($row3['totsum']); else echo '-';?></td>
						<?php
					}
				}
				?>
				<td class="tot2"><?php if(($val[3]+$val[4])!=0)echo moneyFormatIndia($val[3]+$val[4]); else echo "-"; ?></td>
				<td class="tot2"><?php if(($val[2]+$val[3]+$val[5]+$val[4])!=0) echo moneyFormatIndia($val[2]+$val[3]+$val[5]+$val[4]); else echo "-" ?></td>
				<td class="tot2"><?php echo moneyFormatIndia($val[1]-$val[2]-$val[3]-$val[4]-$val[5]); ?></td>
				</tr>
				<?php
			}
		?>
		<tr>
		 	<th class="tot2">TOTAL</th>
		 	<?php
		 		$val=[];
		 		$f=0;
		 		$RE2=$conn->query("select sum(Revised_Est) as estsum from est_val where Budgettype=1 and FY='".$_POST["fy"]."' ;");
		 		while($row2=$RE2->fetch_assoc())
		 		{
		 			?>
					<td class="tot2"><?php $f=1;$val[1]=$row2['estsum']; echo moneyFormatIndia($row2['estsum']); ?></td>
					<?php
		 		}
		 		if($f==0){?><td class="tot2">-</td><?php }
		 		for($accid=1;$accid<=4;$accid++)
				{
					//echo "select sum(Amount) as totsum from funddetails where Budgettype=1 and Disci_id=".$row2['id']." and Accheads=".$accid."; ";
					$RE3=$conn->query("select sum(Amount) as totsum from funddetails where Budgettype=1 and Accheads=".$accid." and FY='".$_POST["fy"]."' ; ");
					while($row3=$RE3->fetch_assoc())
					{
						?>
						<td class="tot2"><?php $val[$accid+1]=$row3['totsum']; if($row3['totsum']!=NULL)echo moneyFormatIndia($row3['totsum']); else echo '-';?></td>
						<?php
					}
				}
				?>
				<td class="tot2"><?php if(($val[3]+$val[4])!=0)echo moneyFormatIndia($val[3]+$val[4]); else echo "-"; ?></td>
				<td class="tot2"><?php if(($val[2]+$val[3]+$val[5]+$val[4])!=0) echo moneyFormatIndia($val[2]+$val[3]+$val[5]+$val[4]); else echo "-" ?></td>
				<td class="tot2"><?php echo moneyFormatIndia($val[1]-$val[2]-$val[3]-$val[4]-$val[5]); ?></td>
		</tr>
		</table>
	<?php	
	}
	else if($_POST["type"]==2 && $_POST["disci"]!=0)
	{
		if($_POST["disci"]==1)
		{
			?>
			<table class="detail">
			<tr>
				<th class="smallcenter2" colspan="9">SUMMARY OF BUDGET WITH EXPENDITURE FOR THE F.Y 
				<?php
					$RE0=$conn->query("select * from years where val='".$_POST["fy"]."';");
					while($row0=$RE0->fetch_assoc())
					{
						$curryear=$row0['val'];
						$prevyear=$row0['prev'];
					}
					echo $curryear;
				?>
				</th>
			</tr>
			<tr>
				<th class="smallcenter2" rowspan="2">Heads</th>
				<th class="smallcenter2" rowspan="2">Revised Estimate</th>
				<th class="smallcenter2" colspan="7">Expenditure <?php echo $curryear; ?> including carried forward from F.Y 
				<?php
					echo $prevyear;
				?>
				(in Lakhs)</th>
			</tr>
			<tr>
			<?php
				$RE1=$conn->query("select * from equip_accheads;");
				while($row1=$RE1->fetch_assoc())
				{
					?>
					<th class="smallcenter"><?php echo $row1['name']; echo ' ('; echo $prevyear ; echo ' & '; echo $curryear; echo ')';?></th>
					<?php
				}
			?>
			<th class="smallcenter2">Total <?php echo '('; echo $prevyear ; echo ' & '; echo $curryear; echo ')';?></th>
			</tr>
			<tr>
				<th class="smallcenter2"></th>
				<th class="smallcenter2"></th>
				<th class="smallcenter2">[A]</th>
				<th class="smallcenter2">[B]</th>
				<th class="smallcenter2">[C]</th>
				<th class="smallcenter2">[D]</th>
				<th class="smallcenter2">[E]</th>
				<th class="smallcenter2">[F]</th>
				<th class="smallcenter2">[G]=[A]+[B]+[C]+[D]+[E]+[F]</th>
			</tr>
			<?php
				$RES0=$conn->query("select max(id) as maxi from equip_capitalheads;");
				while($rows0=$RES0->fetch_assoc())
				{
					$maxid=$rows0['maxi'];
				}
				$RE2=$conn->query("select * from equip_capitalheads;");
				while($row2=$RE2->fetch_assoc())
				{
					$tot=0;
					?>
					
					<tr>
					<th class="smallleft"><?php echo $row2['name']; ?></th>
					<?php
						if($row2['id']==1)
						{
							$RE3=$conn->query("select sum(Revised_Est) as totsum from est_val where Budgettype=2 and FY='".$_POST["fy"]."' ;");
							while($row3=$RE3->fetch_assoc())
							{
								?>
								<td class="smallcenter2" rowspan="<?php echo $maxid; ?>"><?php $totsum=$row3['totsum']; if($row3['totsum']!=0)echo round($row3['totsum']/100000.0,2); else echo "-"; ?></th>
								<?php
							}
						}
						$tot=0;
						for($accid=1;$accid<=6;$accid++)
						{
							$RE4=$conn->query("select sum(Amount) as total from funddetails where Budgettype=2 and Accheads=".$accid." and Equip_captype=".$row2['id']."  and FY='".$_POST["fy"]."' ;");
							while($row4=$RE4->fetch_assoc())
							{
								?>
								<td class="smallcenter2"><?php $tot+=$row4['total']; if($row4['total']!=0)echo round($row4['total']/100000.0,2); else echo "-";?></th>
								<?php
							}
						}
					?>
					<td class="smallcenter2"><?php echo round($tot/100000.0,2); ?></th>
					</tr>
					<?php
				}
			?>
			<tr>
				<th class="tot">TOTAL</th>
				<th class="smallrb"><?php if($totsum!=0)echo round($totsum/100000.0,2); else echo "-"; ?></th>
				<?php
				$tot=0;
				for($accid=1;$accid<=6;$accid++)
				{
					$RE5=$conn->query("select sum(Amount) as total from funddetails where Budgettype=2 and Accheads=".$accid." and FY='".$_POST["fy"]."'  ;");
					while($row5=$RE5->fetch_assoc())
					{
						?>
						<th class="smallrb"><?php $tot+=$row5['total']; if($row5['total']!=0)echo round($row5['total']/100000.0,2); else echo "-";?></th>
						<?php
					}
				}
				?>
				<th class="smallrb"><?php echo round($tot/100000.0,2); ?></th>
			</tr>
			</table>
			<?php
		}
		if($_POST["disci"]==2)
		{
			?>
			<table class="detail">
			<tr>
				<th class="smallcenter2" colspan="9">SUMMARY OF BUDGET WITH EXPENDITURE FOR THE F.Y 
				<?php
					$RE0=$conn->query("select * from years where val='".$_POST["fy"]."';");
					while($row0=$RE0->fetch_assoc())
					{
						$curryear=$row0['val'];
						$prevyear=$row0['prev'];
					}
					echo $curryear;
				?>
				</th>
			</tr>
			<tr><td class="blank" colspan="9"></td></tr>
			<?php
			for($times=1;$times<=2;$times++)
			{ 
			?>
				<tr>
					<th class="smallcenter2" rowspan="2">Heads</th>
					<th class="smallcenter2" rowspan="2">Revised Estimate</th>
					<th class="smallcenter2" colspan="7">
					<?php 
					if($times==1) 
					{
						echo "Carried Forward Expenditure ";
						echo $prevyear;
						echo " (in Lakhs)";
					}
					else
					{
						echo "Expenditure ";
						echo $curryear;
						echo " (in Lakhs)";
					}
					?>
					</th>
				</tr>
				<tr>
				<?php
					$RE1=$conn->query("select * from equip_accheads;");
					while($row1=$RE1->fetch_assoc())
					{
						?>
						<th class="smallcenter"><?php echo $row1['name'];?></th>
						<?php
					}
				?>
				<th class="smallcenter2">Total </th>
				</tr>
				<tr>
					<th class="smallcenter2"></th>
					<th class="smallcenter2"></th>
					<th class="smallcenter2">[A]</th>
					<th class="smallcenter2">[B]</th>
					<th class="smallcenter2">[C]</th>
					<th class="smallcenter2">[D]</th>
					<th class="smallcenter2">[E]</th>
					<th class="smallcenter2">[F]</th>
					<th class="smallcenter2">[G]=[A]+[B]+[C]+[D]+[E]+[F]</th>
				</tr>
				<?php
					$RES0=$conn->query("select max(id) as maxi from equip_capitalheads;");
					while($rows0=$RES0->fetch_assoc())
					{
						$maxid=$rows0['maxi'];
					}
					$RE2=$conn->query("select * from equip_capitalheads;");
					while($row2=$RE2->fetch_assoc())
					{
						$tot=0;
						?>
						
						<tr>
						<th class="smallleft"><?php echo $row2['name']; ?></th>
						<?php
							if($row2['id']==1)
							{
								$RE3=$conn->query("select sum(Revised_Est) as totsum from est_val where Budgettype=2 and FY='".$_POST["fy"]."' ;");
								while($row3=$RE3->fetch_assoc())
								{
									?>
									<td class="smallcenter2" rowspan="<?php echo $maxid; ?>"><?php $totsum=$row3['totsum']; if($row3['totsum']!=0)echo round($row3['totsum']/100000.0,2); else echo "-"; ?></th>
									<?php
								}
							}
							$tot=0;
							for($accid=1;$accid<=6;$accid++)
							{
								$RE4=$conn->query("select sum(Amount) as total from funddetails where Budgettype=2 and Accheads=".$accid." and Equip_captype=".$row2['id']." and Equip_exptype=".$times." and FY='".$_POST["fy"]."' ; ");
								while($row4=$RE4->fetch_assoc())
								{
									?>
									<td class="smallcenter2"><?php $tot+=$row4['total']; if($row4['total']!=0)echo round($row4['total']/100000.0,2); else echo "-";?></th>
									<?php
								}
							}
						?>
						<td class="smallcenter2"><?php echo round($tot/100000.0,2); ?></th>
						</tr>
						<?php
					}
				?>
				<tr>
					<th class="tot">TOTAL</th>
					<th class="smallrb"><?php if($totsum!=0)echo round($totsum/100000.0,2); else echo "-"; ?></th>
					<?php
					$tot=0;
					for($accid=1;$accid<=6;$accid++)
					{
						$RE5=$conn->query("select sum(Amount) as total from funddetails where Budgettype=2 and Accheads=".$accid." and Equip_exptype=".$times." and FY='".$_POST["fy"]."' ;");
						while($row5=$RE5->fetch_assoc())
						{
							?>
							<th class="smallrb"><?php $tot+=$row5['total']; if($row5['total']!=0)echo round($row5['total']/100000.0,2); else echo "-";?></th>
							<?php
						}
					}
					?>
					<th class="smallrb"><?php echo round($tot/100000.0,2); ?></th>
				</tr>
			<?php 
			if($times==1){ ?><tr><td class="blank" colspan="9"></td></tr> <?php }
			}
			?>
			</table>
			<?php
		}
	}
}
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gethead(val1,val2)
{
   $.ajax({
      type: 'post',
      url: 'getsumhead.php',
      data: {
        gethead: val1,
        disci1: val2
      },
      success: function (response) {
       document.getElementById("disci").innerHTML=response; 
     }
   });
}
</script>

<h2 class="choose1">CHOOSE</h2>
<form action="summary.php" method="post">
<select class="fy" name="fy" id="fy">
<option value=0>Select The FY</option> 
	<?php
		$RE0=$conn->query("select distinct(FY) as fy from funddetails;");
		while($row0=$RE0->fetch_assoc())
		{
			?>
			<option id="<?php echo $row0['fy']; ?>"><?php echo $row0['fy']; ?></option>
			<?php
		}
	?>
</select>
<select class="type1" name="type" id="type" onchange="gethead(this.value,0)">
<option value=0>Select The Budget Type</option> 
<option value=1>Recurring Budget</option>
<option value=2>Equipment Budget</option>
</select>
<select class="disci1" name="disci" id="disci">
  <option value=0>Select Summary Type</option>
 </select>
 <input name="submit" class="submit1" src="images/submit.png" type="image">
 </form>
 <script type="text/javascript">
  <?php if($_POST["fy"]!=0){ ?> document.getElementById('fy').value= "<?php echo $_POST["fy"]; ?>"; <?php } ?>
  <?php if(isset($_POST["type"]) && $_POST["type"]!=0) {?>document.getElementById('type').value = "<?php echo $_POST["type"];?>"; gethead(<?php echo $_POST["type"]; ?>,<?php echo $_POST["disci"];?>); <?php } ?>
</script>