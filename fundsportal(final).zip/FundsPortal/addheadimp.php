<?php
include("connection.php");

if(isset($_POST["username"]))
{
	if($_POST["type"]==1)
	{
		
		$q1='select MAX(id) as maxi FROM recur_heads;';
		$re1=$conn->query($q1);
		while($row1=$re1->fetch_assoc())
		{
			$idval=$row1['maxi'];
		}
		$idval++;
		$q='insert into recur_heads(id,name) values('.$idval.',"'.$_POST["username"].'") ';
		$res=$conn->query($q);
	}

	else if($_POST["type"]==2)
	{
		
		$q1='select MAX(id) as maxi FROM equip_heads;';
		$re1=$conn->query($q1);
		while($row1=$re1->fetch_assoc())
		{
			$idval=$row1['maxi'];
		}
		$idval++;
		$q='insert into equip_heads(id,name) values('.$idval.',"'.$_POST["username"].'") ';
		$res=$conn->query($q);
	}

}
else
{
	header("Location: login.php");
}
?>