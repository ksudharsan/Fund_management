<?php
session_start();
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]!="admin_limi")header("Location: login.php");
}
else
{
	header("Location: login.php");
}
?>