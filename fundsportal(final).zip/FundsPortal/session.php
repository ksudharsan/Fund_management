<?php
session_start();
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="admin")header("Location: adminmenu.php");
	else if($_SESSION["type"]=="admin_limi")header("Location: adminlim.php");
	else if($_SESSION["type"]=="hod")header("Location: hodmenu.php");
	else if($_SESSION["type"]=="hos")header("Location: hosmenu.php");
}
else
{
	header("Location: login.php");
}
?>