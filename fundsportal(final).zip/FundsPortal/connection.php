<?php
$conn = new mysqli("localhost","root","","funds");
if (!$conn)
{
	die('Could not connect: ' . mysqli_errno($conn));
}
?>
