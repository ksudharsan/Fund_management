<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	function myfunction(val1,val2)
	{
		var x=confirm("Are You Sure You Want to add this Head \"<?php echo $_POST["uid"];?>\"..??");
		if(x==true)
		{
			$.ajax({
	     	type: 'post',
	     	url: 'addheadimp.php',
	     	data: {
	    	   username: val1,
	    	   type:val2
	    	 },
	    	success: function (response) {
	    			alert("Head Successfully Added..!!"),
	         		window.location.assign("addhead.php")
	         		//getElementById('qwerty').innerHTML=response;
	         		//alert(response);
	     		}
	   		});
		}
		else return false;
	}
</script>
<?php
if(isset($_POST["sub"]))
{
	if($_POST["btype"]!=0)
	{
		if(isset($_POST["uid"]) && $_POST["uid"]!="")
		{
			?>
			<script>
			myfunction("<?php echo $_POST["uid"]; ?>",<?php echo $_POST["btype"];?>);
			</script>
			<?php 
		}
		else
		{
			?>
			<p class="addhead_err">Please Enter A Head Name.</p>
			<?php
		}

	}
	else
	{
		?>
		<p class="addhead_err">Please Enter A Budget Type.</p>
		<?php
	}
}
?>

<img class="addimg" src="images/addimg.png"></img>
<h2 class="addhead">ADD HEADS</h2>
<form action="addhead.php" method="post">
<input type="hidden" value="123" name="sub">
<select class="addhead" name="btype" id="btype">
	<option value=0>Select The Bugdet Type</option>
	<option value=1>Recurring Budget</option>
	<option value=2>Equipment Budget</option>
</select>
<p class="addheadname">Please Enter The Head Name</p>
<input class="addheadname" id="uid" name="uid" type="text">
<input class="addheadsub" name="submit" type="image" src="images/submit.png"> 
</form>
<script type="text/javascript">
  <?php if(isset($_POST["btype"])) {?>document.getElementById('btype').value = "<?php echo $_POST["btype"];?>";<?php } ?>
</script>