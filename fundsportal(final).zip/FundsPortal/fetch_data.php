<?php
include("connection.php");
if(isset($_POST['get_option']))
{
  $btype=$_POST['get_option'];
  if($btype==2)
  {
?>
    <select class="cap_head" name="cap_head">
    <option selected> Select The Capital Head </option>

    <?php
    $caphead=$conn->query("Select id,name from equip_capitalheads;");
    while($row=$caphead->fetch_assoc())
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    ?>

    </select>
    <select class="exptype" name="exptype">
    <option selected >Select The Expenditure Type</option>
    <option value=1>Carried Forward Expenditure</option>
    <option value=2>Expenditure</option>
    </select>

    <select class="eq_accheads" name="eq_accheads">
    <option selected >Select The Accounting Head</option>
    
    <?php 
    $acchead=$conn->query("Select name,id from equip_accheads;");
    while($row=$acchead->fetch_assoc())
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    echo "</select>";
    
    ?>

  <?php
  }
  else if($btype==1)
  {
  ?>
    
    <select class="re_accheads" name="re_accheads">
    <option selected value="0">Select The Accounting Head</option>
    
    <?php 
    $acchead=$conn->query("Select name,id from recur_accheads");
    while($row=$acchead->fetch_assoc())
    {
      echo "<option value=".$row['id'].">".$row['name']."</option>";
    }
    ?>
    </select>
<?php
  }
  else 
{
    header("Location:login.php");
}
  ?>
<br>
<br>
<table class="tabs">
<tr>
  <td class="tabs">Entry Date</td>
  <td class="tabs"><input class="tabs" type="date" name="entrydate"></td>
</tr>
<tr>
  <td class="tabs">Particulars</td>
  <td class="tabs"><input class="tabs" type="text" name="particulars"></td>
</tr>
<tr>
  <td class="tabs">Year</td>
  <td class="tabs"><input class="tabs" type="text" name="year"></td>
</tr>
<tr>
  <td class="tabs">Indentor</td>
  <td class="tabs"><input class="tabs" type="text" name="indentor"></td>
</tr>
<tr>
  <td class="tabs">Indent Type</td>
  <td class="tabs"><select class="tabs" name="indenttype" onchange="indtype(this.value)">
                        <option value=0>Select Indent Type</option>
                        <option value=1>By Indent No.</option> 
                        <option value=2>Direct Purchase</option>
                        <option value=3>Direct Purchase(Advance)</option>
                        <option value=4>Others</option>
  </td>
</tr>
<tr>
  <td class="tabs">Amount</td>
  <td class="tabs"><input class="tabs" type="text" name="amount"></td>
</tr>
<tr>
  <td class="tabs">Remarks</td>
  <td class="tabs"><input class="tabs" type="text" name="remarks"></td>
</tr>
</table>
<br>
<input type="submit" value="submit" name="submit" class="sub">

<div id="ind">
</div>

<?php
}
?>

