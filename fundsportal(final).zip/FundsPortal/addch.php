<?php
include("connection.php");

if(isset($_POST["username"]))
{
	$q1='select MAX(id) as maxi FROM equip_capitalheads;';
	$re1=$conn->query($q1);
	while($row1=$re1->fetch_assoc())
	{
		$idval=$row1['maxi'];
	}
	$idval++;
	$q='insert into equip_capitalheads values('.$idval.',"'.$_POST["username"].'") ';
	$res=$conn->query($q);

}
else
{
	header("Location: login.php");
}
?>