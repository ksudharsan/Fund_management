<?php
include("connection.php");

if(isset($_POST['gethead']))
{
    if($_POST['gethead']==1)
    {
        ?>
        <option value="1">Detailed</option>
        <?php
    } 
    else if($_POST['gethead']==2)
    {
        ?>
        <option value="1">Very Short</option>
        <option value="2">Short</option>
        <?php
    }
    else
    {
        ?>
        <option value=0 selected>Select Summary Type</option>
        <?php
    }
}
else 
{
    header("Location:login.php");
}
?>  