<?php
session_start(); 
include("header.php"); 
include("isadmin.php");
include("connection.php");
?>

<h2 class="adminmenu">ADMIN MENU</h2>
<a href="adminadd.php"><img class="add" src="images/detailsadd.ico"></img></a>
<a href="adminedit.php"><img class="edit" src="images/detailsedit.png"></img></a>
<a href="adminview.php"><img class="view" src="images/detailsview.gif"></img></a>
<a href="summary.php"><img class="summary" src="images/viewsummary.png"></img></a>
<a href="adminacc.php"><img class="acc" src="images/adminacc..ico"></img></a>
<a href="adminest.php"><img class="est" src="images/adminest.png"></img></a>
<a href="addhead.php"><img class="addrehead" src="images/addrehead.png"></img></a>
<a href="addcaphead.php"><img class="addeqcaphead" src="images/addeqcaphead.png"></img></a>
<a href="curryear.php"><img class="backup" src="images/calender.ico"></img></a>

<p class="add">ADD DETAILS</p>
<p class="edit">EDIT DETAILS</p>
<p class="view">VIEW DETAILS</p>
<p class="summary">VIEW SUMMARY</p>
<p class="acc">MANAGE USERS</p>
<p class="est">UPDATE ESTIMATE</p>
<p class="addeqhead">ADD HEADS</p>
<p class="addeqcaphead">ADD EQUIPMENT</p>
<p class="addeqcaphead1">CAPITAL HEAD</p>
<p class="backup">CHANGE</p>
<p class="restore">CURRENT YEAR</p>