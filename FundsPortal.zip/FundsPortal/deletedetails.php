<?php
include("connection.php");
if(isset($_POST['sno']))
{
	$q='delete from funddetails where SNo="'.$_POST["sno"].'"';
	$res=$conn->query($q);
}
?>