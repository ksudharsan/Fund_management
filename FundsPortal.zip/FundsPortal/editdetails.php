<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");

if(isset($_POST["submit"]))
{
   if($_POST["type"]==1)
   {
        if($_POST["indenttype"]==1)
        {
            $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Indent_no='.$_POST['indentno'].',PO_no='.$_POST['pono'].',IndentAmt='.$_POST['indentamt'].',Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['recur_accheads'].',Discipline='.$_POST['disci'].',IndentType='.$_POST["indenttype"].' where SNo='.$_POST['old'].';';
            //echo $q;
            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
            
                </script>
                <?php
            }
        }
        else if($_POST["indenttype"]==4)
        {
            $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['recur_accheads'].',Discipline='.$_POST['disci'].',IndentType='.$_POST["indenttype"].',IndentVal="'.$_POST["otherindent"].'" where SNo='.$_POST['old'].';';

            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
            
                </script>
                <?php
            }
        } 
        else
        {
             $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['recur_accheads'].',Discipline='.$_POST['disci'].',IndentType='.$_POST["indenttype"].' where SNo='.$_POST['old'].';';

            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
            
                </script>
                <?php
            }
        }
    }
    else
    {
        if($_POST["indenttype"]==1)
        {
            $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Indent_no='.$_POST['indentno'].',PO_no='.$_POST['pono'].',IndentAmt='.$_POST['indentamt'].',Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['equip_accheads'].',Discipline='.$_POST['disci'].',Equip_captype='.$_POST['cap_head'].',Equip_exptype='.$_POST['exptype'].',IndentType='.$_POST["indenttype"].' where SNo='.$_POST['old'].';';

            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";

                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
            
                </script>
                <?php
            }
        }
        else if($_POST["indenttype"]==4)
        {
            $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['equip_accheads'].',Discipline='.$_POST['disci'].',Equip_captype='.$_POST['cap_head'].',Equip_exptype='.$_POST['exptype'].',IndentType='.$_POST["indenttype"].',IndentVal="'.$_POST["otherindent"].'" where SNo='.$_POST['old'].';';

            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
            
                </script>
                <?php
            }
        } 
        else
        {
            $q='update funddetails set EntryDate="'.$_POST['entrydate'].'",Particulars="'.$_POST['particulars'].'",Year="'.$_POST['year'].'",Indentor="'.$_POST['indentor'].'",Amount='.$_POST['amount'].',Remarks="'.$_POST['remarks'].'",Budgettype='.$_POST['type'].',Accheads='.$_POST['equip_accheads'].',Discipline='.$_POST['disci'].',Equip_captype='.$_POST['cap_head'].',Equip_exptype='.$_POST['exptype'].',IndentType='.$_POST["indenttype"].' where SNo='.$_POST['old'].';';

            $res=$conn->query($q);
            if($res)
            {
                ?>
                <script>
                alert("Data Successfully Updated..!!");
                window.location = "adminedit.php";
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                alert("Data Updation Failed. Please Check The Values and TRY AGAIN..!!");
                window.location = "adminedit.php";
                alert("<?php echo $q; ?>" ); 
                </script>
                <?php
            }
        }
   }
}

?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">


function indtype(val1,val2,val3,val4,val5)
{
 $.ajax({
   type: 'post',
   url: 'editindent.php',
   data: {
     indenttype: val1,
     indentval:val2,
     indentno:val3,
     pono:val4,
     indentamt:val5
   },
   success: function (response) {
     document.getElementById("ind").innerHTML=response; 
   }
 });
}

</script>

<p class="logout"><a href="logout.php">LOGOUT</a></p>
<h2 class="newdetails">ENTER NEW DETAILS</h2>
<form action="editdetails.php" method="post">


<?php

$q='select * from funddetails where SNo="'.$_POST["sno"].'" ';
$RE1=$conn->query($q);
while($row1=$RE1->fetch_assoc())
{
?>
	<input type="hidden" name="old" value="<?php echo $row1['SNo']; ?>"/>
  <input type="hidden" name="type" value="<?php echo $row1['Budgettype']; ?>"/>

  <?php 
  if($row1['Budgettype']==1)
  {
      ?>
      <select class="disci" name="disci">
          <?php
              $RE2=$conn->query("select id,name from recur_heads;");
              while($row2=$RE2->fetch_assoc())
              {
                  ?>
                  <option value="<?php echo $row2['id']; ?>" <?php if($row1['Discipline']==$row2['id']) echo "selected"; ?> ><?php echo $row2['name']; ?></option>
                  <?php
              }
          ?>
      </select>
      <select class="re_accheads" name="recur_accheads">
        <?php 
        $RE3=$conn->query("Select name,id from recur_accheads");
        while($row3=$RE3->fetch_assoc())
        {
            ?>
            <option value="<?php echo $row3['id']; ?>" <?php if($row1['Accheads']==$row3['id']) echo "selected"; ?> ><?php echo $row3['name']; ?></option>
            <?php
        }
        ?>
      </select>
      <?php
  } 
  else if($row1['Budgettype']==2)
  {
      ?>
      <select class="disci" name="disci">
          <?php
              $RE2=$conn->query("select id,name from equip_heads;");
              while($row2=$RE2->fetch_assoc())
              {
                  ?>
                  <option value="<?php echo $row2['id']; ?>" <?php if($row1['Discipline']==$row2['id']) echo "selected"; ?> ><?php echo $row2['name']; ?></option>
                  <?php
              }
          ?>
      </select>

      <select class="cap_head" name="cap_head">
      <?php
      $RE3=$conn->query("Select id,name from equip_capitalheads;");
      while($row3=$RE3->fetch_assoc())
      {
          ?>
          <option value="<?php echo $row3['id']; ?>" <?php if($row1['Equip_captype']==$row3['id']) echo "selected"; ?> ><?php echo $row3['name']; ?></option>
          <?php
      }
      ?>

      </select>
      <select class="exptype" name="exptype">
        <option value=1 <?php if($row1['Equip_exptype']==1) echo "selected"; ?> >Carried Forward Expenditure</option>
        <option value=2 <?php if($row1['Equip_exptype']==2) echo "selected"; ?> >Expenditure</option>
      </select>

      <select class="eq_accheads" name="equip_accheads">
      <?php 
      $RE4=$conn->query("Select name,id from equip_accheads;");
      while($row4=$RE4->fetch_assoc())
      {
          ?>
          <option value="<?php echo $row4['id']; ?>" <?php if($row1['Equip_accheads']==$row4['id']) echo "selected"; ?> ><?php echo $row4['name']; ?></option>
          <?php
      }
      ?>
      </select>
      <?php
  }
  ?>

  

  <br>
<br>
<table class="tabs">
<tr>
  <td class="tabs">Entry Date</td>
  <td class="tabs"><input class="tabs" type="date" name="entrydate" value="<?php echo $row1['EntryDate']; ?>"></td>
</tr>
<tr>
  <td class="tabs">Particulars</td>
  <td class="tabs"><input class="tabs" type="text" name="particulars" value="<?php echo $row1['Particulars']; ?>"></td>
</tr>
<tr>
  <td class="tabs">Year</td>
  <td class="tabs"><input class="tabs" type="text" name="year" value="<?php echo $row1['Year']; ?>"></td>
</tr>
<tr>
  <td class="tabs">Indentor</td>
  <td class="tabs"><input class="tabs" type="text" name="indentor" value="<?php echo $row1['Indentor']; ?>"></td>
</tr>
<tr>
  <td class="tabs">Indent Type</td>
  <td class="tabs"><select class="tabs" name="indenttype" onchange="indtype(this.value,'<?php echo $row1['IndentVal']; echo '\', \''; echo $row1['Indent_no']; echo '\', \''; echo $row1['PO_no']; echo '\', \''; echo $row1['IndentAmt'];?>')" >
                        <option value=1 <?php if($row1['IndentType']==1) echo "selected"; ?> >By Indent No.</option> 
                        <option value=2 <?php if($row1['IndentType']==2) echo "selected"; ?> >Direct Purchase</option>
                        <option value=3 <?php if($row1['IndentType']==3) echo "selected"; ?> >Direct Purchase(Advance)</option>
                        <option value=4 <?php if($row1['IndentType']==4) echo "selected"; ?> >Others</option>
  </td>
</tr>
<tr>
  <td class="tabs">Amount</td>
  <td class="tabs"><input class="tabs" type="text" name="amount" value="<?php echo $row1['Amount']; ?>"></td>
</tr>
<tr>
  <td class="tabs">Remarks</td>
  <td class="tabs"><input class="tabs" type="text" name="remarks" value="<?php echo $row1['Remarks']; ?>"></td>
</tr>
</table>
<script>
indtype('<?php echo $row1['IndentType']; echo '\', \''; echo $row1['IndentVal']; echo '\', \''; echo $row1['Indent_no']; echo '\', \''; echo $row1['PO_no']; echo '\', \''; echo $row1['IndentAmt'];?>');
</script>

<br>
<div id="ind"></div>
<input type="submit" value="submit" name="submit" class="sub">
</form>
<?php 
}
?> 
  