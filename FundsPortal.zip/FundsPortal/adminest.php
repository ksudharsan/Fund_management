<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");

if(isset($_POST["submit"]))
{
	if($_POST["type"]!=0)
	{
		if($_POST["disci"]!=0)
		{
			if($_POST["estval"]!="")
			{
				$q='select * from est_val where Budgettype='.$_POST["type"].' and Disci_id='.$_POST["disci"].'';
				$res=$conn->query($q);
				if(mysqli_num_rows($res))
				{
					$q1='update est_val set Budgettype='.$_POST["type"].', Disci_id='.$_POST["disci"].', Revised_Est='.$_POST["estval"].' where Budgettype='.$_POST["type"].' and Disci_id='.$_POST["disci"].'';
					$res1=$conn->query($q1);
					{
						if($res1)
						{
							?>
							<p class="esterr1">Revised Estimate Value Successfully Updated..!</p>
							<?php
						}
						else
						{
							?>
							<p class="esterr1">Updation Failed..! Please Check the Value Entered.</p>
							<?php
						}
					}
				}
				else
				{
					$q1='insert into est_val values('.$_POST["type"].','.$_POST["disci"].','.$_POST["estval"].') ';
					$res1=$conn->query($q1);
					{
						if($res1)
						{
							?>
							<p class="esterr1">Revised Estimate Value Successfully Added..!</p>
							<?php
						}
						else
						{
							?>
							<p class="esterr1">Insertion Failed..! Please Check the Value Entered.</p>
							<?php
						}
					}
				}
			}
			else
			{
				?>
				<p class="esterr">Please Enter an Estimate Value..!</p>
				<?php
			}
		}
		else
		{
			?>
			<p class="esterr">Please Select A Head..!</p>
			<?php
		}
	}
	else
	{
		?>
		<p class="esterr">Please Select A Budget Type..!</p>
		<?php
	}
}
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gethead(val1,val2)
{
   $.ajax({
      type: 'post',
      url: 'gethead.php',
      data: {
        gethead: val1,
        disci1: val2
      },
      success: function (response) {
       document.getElementById("disci").innerHTML=response; 
     }
   });
}
</script>

<p class="logout"><a href="logout.php">LOGOUT</a></p>
<h2 class="est">UPDATE REVISED ESTIMATE</h2>
<form action="adminest.php" method="post">
<select class="esttype" name="type" id="type" onchange="gethead(this.value,0)">
<option value=0>Select The Budget Type</option> 
<option value=1>Recurring Budget</option>
<option value=2>Equipment Budget</option>
</select>
<select class="estdisci" name="disci" id="disci">
  <option value=0>Select Head</option>
 </select>
 
 <p class="estval">Enter Updated Revised Estimate</p>
 <input class="estval" id="estval" name="estval" type="text">
 <input class="estsub" name="submit" value="Submit" type="submit">
 </form>
 <script type="text/javascript">
  <?php if(isset($_POST["type"])) {?>document.getElementById('type').value = "<?php echo $_POST["type"];?>"; gethead(<?php echo $_POST["type"]; ?>,<?php echo $_POST["disci"];?>); <?php } ?>
  <?php if(isset($_POST["disci"])) {?>document.getElementById('disci').value = "<?php echo $_POST["disci"];?>";<?php } ?>
  <?php if(isset($_POST["estval"])) {?>document.getElementById('estval').value = "<?php echo $_POST["estval"];?>";<?php } ?>
</script>
 