<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	function myfunction(val)
	{
		var x=confirm("Are You Sure You Want to Delete this User..??");
		if(x==true)
		{
			$.ajax({
	     	type: 'post',
	     	url: 'deleteuserssuccess.php',
	     	data: {
	    	   username: val
	    	 },
	    	success: function (response) {
	    			alert("User Successfully Deleted..!!"),
	         		window.location.assign("delete_users.php")
	         		//getElementById('qwerty').innerHTML=response;
	         		//alert(response);
	     		}
	   		});
		}
		else return false;
	}
</script>
<?php
if(isset($_POST["uid"]))
{
	if($_POST["uid"]!="" && isset($_POST["uid"]))
	{
		$q1='select * from users where username="'.$_POST["uid"].'";';
		$res=$conn->query($q1);	
		if(mysqli_num_rows($res))
		{
			?>
			<script>
			myfunction("<?php echo $_POST["uid"]; ?>");
			</script>
			<?php 
		}
		else
		{
			?>
			<p class="chpass_err">No Such User Found.</p>
			<?php
		}
	}
	else
	{
		?>
		<p class="chpass_err">Please Enter A Username.</p>
		<?php
	}
}
?>
<p class="logout"><a href="logout.php">LOGOUT</a></p>
<img class="addimg" src="images/addimg.png"></img>
<h2 class="deluser">Delete Users</h2>
<form action="delete_users.php" method="post">
<p class="ch_uname">Please Enter The Username</p>
<input class="chpass_uname" id="uid" name="uid" type="text">
<input class="chpass_sub" name="submit" type="image" src="images/submit.png"> 
</form>
<div id="qwerty"></div>
<script type="text/javascript">
  <?php if(isset($_POST["uid"])) {?>document.getElementById('uid').value = "<?php echo $_POST["uid"];?>";<?php } ?>
</script>