<?php
include("connection.php");
if($_POST["get_type"]=="admin" || $_POST["get_type"]=="admin_limited")
{
?>
	<p class="add_uname">Username</p>
	<input class="add_uname" id="uid" name="uid" type="text">
	<p class="add_pass">Password</p>
	<input class="add_pass" id="pwd" name="pwd" type="password">
	<p class="add_pass1">Retype-Password</p>
	<input class="add_pass1" id="pwd1" name="pwd1" type="password">
	<input class="add_user_sub" name="submit" value="Submit" type="submit">
<?php
}
else if($_POST["get_type"]=="hos")
{
?>
	<select class="idval" id="idval" name="idval">
        <option value="0" selected>Select School</option>
        <?php
            $q1='select * from school;';
            $res1=$conn->query($q1);
            while($row1=$res1->fetch_assoc())
            {
            	?>
            	<option value=<?php echo "\""; echo $row1['school_id']; echo "\""; ?> > <?php echo $row1['name']; ?></option>
            	<?php
            }
        ?>
    </select>
    <p class="add_uname0">Username</p>
	<input class="add_uname0" id="uid" name="uid" type="text">
	<p class="add_pass0">Password</p>
	<input class="add_pass0" id="pwd" name="pwd" type="password">
	<p class="add_pass10">Retype-Password</p>
	<input class="add_pass10" id="pwd1" name="pwd1" type="password">
	<input class="add_user_sub0" name="submit" value="Submit" type="submit">
<?php
}
else if($_POST["get_type"]=="hod")
{
?>
	<select class="idval1" id="idval" name="idval">
        <option value="0" selected>Select Discipline</option>
        <?php
            $res1=$conn->query("select * from discipline;");
            while($row1=$res1->fetch_assoc())
            {
              echo "<option value=".$row1['disci_id'].">".$row1['name']."</option>";
            }
        ?>
    </select>
    <p class="add_uname0">Username</p>
	<input class="add_uname0" id="uid" name="uid" type="text">
	<p class="add_pass0">Password</p>
	<input class="add_pass0" id="pwd" name="pwd" type="password">
	<p class="add_pass10">Retype-Password</p>
	<input class="add_pass10" id="pwd1" name="pwd1" type="password">
	<input class="add_user_sub0" name="submit" value="Submit" type="submit">
<?php 
}
?>



	