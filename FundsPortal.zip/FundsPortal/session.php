<?php
session_start();
if(isset($_SESSION["userid"]) && $_SESSION["type"]=="admin")
{

}
else
{
	header("Location: login.php");
}
?>