<?php
session_start();
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="hod")
	{
		header("Location: hodmenu.php");
	}
	else if($_SESSION["type"]=="hos")
	{	
		header("Location: hosmenu.php");
	}
	else if($_SESSION["type"]=="admin_limi")
	{
		header("Location: adminlimited.php");
	}
	else if($_SESSION["type"]=="admin")
	{
		header("Location: adminmenu.php");
	}	
}
include("header.php"); 
include("connection.php");
$failure="Login failed..Please try again..!!";
if(isset($_POST["uid"]) && isset($_POST["pwd"]))
{
	$result=$conn->query("SELECT * from users WHERE username='$_POST[uid]'");
	while($row=$result->fetch_assoc())
	{
		$pwdmd5=$row["password"];
		$type=$row["usertype"];
	}
	if(md5($_POST["pwd"])==$pwdmd5)
	{
		$_SESSION["userid"]=$_POST["uid"];
		$_SESSION["type"]=$type;
		if($type=="hod")
		{
			header("Location: hodmenu.php");
		}
		if($type=="hos")
		{
			header("Location: hosmenu.php");
		}
		else if($type=="admin_limi")
		{
			header("Location: adminlimited.php");
		}
		else if($type=="admin")
		{
			header("Location: adminmenu.php");
		}	
	}
}
?>

<section id="content">
		<header class="postheader">
  			Login
  		</header>
  			<form action="login.php" method="post">
   				<p class="utextfield">Username</p>
        	   	<input class="uid" name="uid" value="" type="text">
   				<p class="ptextfield">Password</p>
       			<input class="pwd" name="pwd" value="" type="password">
 	  			<p class="submit"><input name="submit" id="submit" src="images/submit.png" type="image"></p>
 	  			<div class="fail">
 	  			<?php
 	  			if(isset($_POST["uid"]) && isset($_POST["pwd"]))
				{
					if(md5($_POST["pwd"])!=$pwdmd5)
					{
						echo $failure;
					}	
				}
 	  			?>
 	  			</div>
			</form>
</section>

<?php include("footer.php"); ?>