<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>
<p class="logout"><a href="logout.php">LOGOUT</a></p>
<img class="outimg" src="images/addsuccess.jpg"></img>
<a href="adminedit.php"><img class="back" src="images/back.png"></img><div>BACK</div></a>
<div class="output2">Values Successfully Changed.</div>

