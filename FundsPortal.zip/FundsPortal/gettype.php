<?php
include("connection.php");
?>

<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>

<?php 
if(isset($_POST['get_type']))
{
  	if($_POST['get_type']==1)
  	{
	?>
		<select class="disci" name="disci" onchange="fetch_next(1)">
	        <option selected >Select Head</option>
	        <?php
	            $res=$conn->query("select id,name from recur_heads;");
	            while($row=$res->fetch_assoc())
	            {
	              echo "<option value=".$row['id'].">".$row['name']."</option>";
	            }
	        ?>
		</select>
    <?php 
    } 
    else if($_POST['get_type']==2)
  	{
	?>
		<select class="disci" name="disci" onchange="fetch_next(2)">
	        <option selected >Select Head</option>
	        <?php
	            $res=$conn->query("select id,name from equip_heads;");
	            while($row=$res->fetch_assoc())
	            {
	              echo "<option value=".$row['id'].">".$row['name']."</option>";
	            }
	        ?>
		</select>
    <?php 
    } ?>
	
	<div id="acchead">
	</div>
	<?php
}
?>

</body>
</html>
