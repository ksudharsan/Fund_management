<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>
<p class="logout"><a href="logout.php">LOGOUT</a></p>
<img class="outimg" src="images/addfailure.jpg"></img>
<a href="adminadd.php"><img class="back" src="images/back.png"></img><div>BACK</div></a>
<div class="output1">Data Insertion Failed.</div>
<div class="output2">Please Check the values Entered.</div>
