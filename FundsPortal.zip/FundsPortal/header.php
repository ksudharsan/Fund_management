<?php
session_start(); 
include("connection.php");
?>
<!doctype html>
<html>
<head>
<title>Fund Management System</title>
<link href="style.css" rel="stylesheet" type="text/css">
<div class="titlebar">
<a href="login.php">
<img class="logo" src="images/logo.png"></img></a>
<div class="title">FUND MANAGEMENT PORTAL</div>
</div>
</head>

<body>
</body>
</html>