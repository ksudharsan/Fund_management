<?php
session_start(); 
include("header.php"); 
include("session.php");

if(isset($_POST["submit"]))
{
	$flag=0;
	if($_POST["type"]=="hos")
	{
		if($_POST["idval"]=="0")
		{
			$flag=1;
			?>
			<script>alert("Please Select a School..!")</script>
			<!-- <p class="adderr">Please Select a School..!</p> -->
			<?php
		}
	}
	else if($_POST["type"]=="hod")
	{
		if($_POST["idval"]=="0")
		{
			$flag=1;
			?>
			<script>alert("Please Select a Discipline..!")</script>
			<!-- <p class="adderr">Please Select a Discipline..!</p> -->
			<?php
		}
	}
	if($flag==0)
	{
		if($_POST["uid"]!="" and isset($_POST["uid"]))
		{
			$Qu='select * from users where username="'.$_POST["uid"].'"';
			$Re=$conn->query($Qu);
			if(mysqli_num_rows($Re))
			{
				?>
				<script>alert("Username Is Already Taken..!")</script>
				<!-- <p class="adderr">Username Is Already Taken..!</p> -->
				<?php
			}
			else
			{
				if($_POST["pwd"]=="" and isset($_POST["pwd"]))
				{
					?>
					<script>alert("PPlease Enter A Password..!")</script>
					<!-- <p class="adderr">Please Enter A Password..!</p> -->
					<?php
				}
				else if($_POST["pwd"]!=$_POST["pwd1"])
				{
					?>
					<script>alert("Passwords Do Not Match..!")</script>
					<!-- <p class="adderr">Passwords Do Not Match..!</p> -->
					<?php
				}	
				else
				{
					if($_POST["type"]=="hod" or $_POST["type"]=="hos")
					{
						$passw=md5($_POST["pwd"]);
						$que='insert into users values ("'.$_POST["uid"].'","'.$passw.'","'.$_POST["type"].'",'.$_POST["idval"].');';
	            		$result=$conn->query($que);
	            		if($result)
	            		{
	            			?>
	            			<script>alert("User Successfully Added..!")</script>
							<!-- <p class="adderr">User Successfully Added..!</p> -->
							<?php
	            		}
	            		else
	            		{
	            			?>
	            			<script>alert("Please Check The Details..!")</script>
							<!-- <p class="adderr">Please Check The Details..!</p> -->
							<?php
	            		}
					}
					else
					{
						$passw=md5($_POST["pwd"]);
						$que='insert into users(username,password,usertype) values ("'.$_POST["uid"].'","'.$passw.'","'.$_POST["type"].'");';
	            		$result=$conn->query($que);
	            		if($result)
	            		{
	            			?>
	            			<script>alert("User Successfully Added..!")</script>
							<!-- <p class="adderr">User Successfully Added..!</p> -->
							<?php
	            		}
	            		else
	            		{
	            			?>
	            			<script>alert("Please Check The Details..!")</script>
							<!-- <p class="adderr">Please Check The Details..!</p> -->
							<?php
	            		}
					}
				}
			}
		}
		else
		{
			?>
			<script>alert("Please Enter A Username..!")</script>
			<!-- <p class="adderr">Please Enter A Username..!</p> -->
			<?php
		}
	}
}

?>

<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gettype(val)
{
   $.ajax({
      type: 'post',
      url: 'getid.php',
      data: {
        get_type: val
      },
      success: function (response) {
       document.getElementById("heads").innerHTML=response; 
     }
   });
}
</script>

<p class="logout"><a href="logout.php">LOGOUT</a></p>
<img class="addimg" src="images/addimg.png"></img>
<h2 class="add_user">ADD USER</h2>
<form action="add_user.php" method="post">
<select class="user_type" id="type" name="type"  onchange="gettype(this.value)">
	<option value="0">Select The User Type</option> 
	<option value="admin">ADMIN</option>
	<option value="admin_limited">ADMIN(VIEW Access Only)</option>
	<option value="hos">Head Of School</option>
	<option value="hod">Head Of Department</option>
</select>
<div id="heads">
</div>
<!-- <p class="add_uname">Username</p>
<input class="add_uname" id="uid" name="uid" value="" type="text">
<p class="add_pass">Password</p>
<input class="add_pass" id="pwd" name="pwd" value="" type="password">
<p class="add_pass1">Retype-Password</p>
<input class="add_pass1" id="pwd1" name="pwd1" value="" type="password">
<input class="add_user_sub" name="submit" value="Submit" type="submit"> -->
</form>
</head>
</html>