<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
function moneyFormatIndia($num){
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){
            // creates each of the 2's group and adds a comma to the end
            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}

?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
function confirmation(val) {
    var r=confirm("Do You Want to Continue ?");
    if(r==true)
    {
    	$.ajax({
     	type: 'post',
     	url: 'deletedetails.php',
     	data: {
    	   sno: val
    	 },
    	success: function (response) {
    			alert("Data Successfully Deleted..!!"),
         		window.location.assign("adminedit.php")
     		}
   		});
    }
    else return false;
}
</script>

<?php
if($_POST["type"]==1 && $_POST["disci"]!=0)
{
?> 
	<table class="detail">
	<tr>
		<th class="head" colspan="8">CONSUMABLES & CONTINGENCIES (
			<?php 
				$RE1=$conn->query("select * from recur_heads where id=".$_POST["disci"]."; ");
				while($row3=$RE1->fetch_assoc())
				{
					echo $row3['name'];
				}
			?> 
		)</th>
	</tr>
	<?php
	$gtotal=0;
    $res=$conn->query("select * from recur_accheads;");
    while($row=$res->fetch_assoc())
    {
    ?>
    	<tr><th class="head" colspan="8">
  		<?php echo $row['name']; ?>
    	</th></tr>
		<tr>
			<th class="detail">Entry Date</th>
			<th class="detail">Particulars</th>
			<th class="detail">Year</th>
			<th class="detail">Indentor</th>
			<th class="detail">Indent No</th>
			<th class="detail">PO no</th>
			<th class="detail">Indent Amt</th>
			<th class="detail">Amount</th>
			<th class="detail">Remarks</th>
		</tr>
		<?php
		$total=0;
		$res1=$conn->query("select * from funddetails where Budgettype=1 and Discipline=".$_POST["disci"]." and Accheads=".$row['id'].""); 
		while($row1=$res1->fetch_assoc())
		{
		?>
			<tr>
				<td class="detail"><?php echo date("d-m-Y",strtotime($row1['EntryDate'])); ?></td>
				<td class="detail"><?php echo $row1['Particulars']; ?></td>
				<td class="detail"><?php echo $row1['Year']; ?></td>
				<td class="detail"><?php echo $row1['Indentor']; ?></td>
				<?php
					if($row1['IndentType']==1)
					{
						?>
						<td class="detail"><?php echo $row1['Indent_no']; ?></td>
						<td class="detail"><?php echo $row1['PO_no']; ?></td>
						<td class="detail"><?php echo moneyFormatIndia($row1['IndentAmt']); ?></td>
						<?php
					} 
					else if($row1['IndentType']==2)
					{
						?>
						<td class="detail" colspan="3">Direct Purchase</td>
						<?php
					}
					else if($row1['IndentType']==3)
					{
						?>
						<td class="detail" colspan="3">Direct Purchase(Through Advance)</td>
						<?php
					}
					else 
					{
						?>
						<td class="detail" colspan="3"><?php echo $row1['IndentVal']; ?></td>
						<?php
					}
				?>
				
				<td class="detail"><?php echo moneyFormatIndia($row1['Amount']);  $total+=$row1['Amount'] ?></td>
				<td class="detail"><?php echo $row1['Remarks']; ?></td>
				<form action="editdetails.php" method="post">
				<input type="hidden" name="sno" value="<?php echo $row1['SNo']; ?>"/>
				<td class="button"><input type="submit" value="EDIT"/></td>

				</form>
				<form>
				<td class="button"><input type="button" value="DELETE" onclick="confirmation(<?php echo $row1['SNo']; ?>)" /></td>
				</form>
			</tr>

		<?php
		}
    } ?>
	</table>

<?php	
}
else if($_POST["type"]==2 && $_POST["disci"]!=0)
{
	?>
	
	<table class="detailnext">
	<tr>
		<th class="head" colspan="8">EQUIPMENT BUDGET (
			<?php 
				$RE1=$conn->query("select * from equip_heads where id=".$_POST["disci"]."; ");
				while($row1=$RE1->fetch_assoc())
				{
					echo $row1['name'];
				}
			?> 
		)</th>
	</tr>
	<tr>
		<th class="smallcenter" colspan="8">DETAILED EXPENDITURE SHEET</th>
	</tr>
	<tr>
		<th class="tot" colspan="8">Revised Estimate</th>
		<td class="detail">
			<?php 
				$RE1=$conn->query("select * from est_val where Budgettype=".$_POST["type"]." and Disci_id=".$_POST["disci"]."; ");
				$f=0;
				while($row1=$RE1->fetch_assoc())
				{
					echo moneyFormatIndia($row1['Revised_Est']);
					$f=1;
					$revised=$row1['Revised_Est'];
				}
				if($f==0)echo "-";
			?>
		</td>
	</tr>
	<?php
		$RE2=$conn->query("select * from equip_capitalheads;");
		while($row2=$RE2->fetch_assoc())
		{
			?>
			<tr>
				<th class="smallcenter" bgcolor="green" colspan="8"><?php echo '('; echo chr($row2['id']+64); echo ')'; echo $row2['name']; ?></th> 
			</tr>
			<?php
				for($exptype=1;$exptype<=2;$exptype++)
				{
					?>
					<tr>
						<th class="smallcenter" bgcolor="green" colspan="8">
							<?php
								echo $exptype+1;
								echo '. ';
								if($exptype==1)echo 'Carried Forward Expenditure';
								else echo 'Expenditure';
							?>
						</th> 				
					</tr>


					<?php
						$gtotal=0;
					    $RE3=$conn->query("select * from equip_accheads;");
					    while($row3=$RE3->fetch_assoc())
					    {
					    ?>
					    	<tr><th class="smallcenter" bgcolor="white" colspan="8">
					  		<?php echo $exptype+1; echo '. '; echo '('; echo chr($row3['id']+96); echo ') '; echo $row3['name']; ?>
					    	</th></tr>
							<tr>
								<th class="detailnext">Entry Date</th>
								<th class="detailnext">Particulars</th>
								<th class="detailnext">Year</th>
								<th class="detailnext">Indentor</th>
								<th class="detailnext">Indent No</th>
								<th class="detailnext">PO no</th>
								<th class="detailnext">Indent Amt</th>
								<th class="detailnext">Amount</th>
								<th class="detailnext">Remarks</th>
							</tr>
							<?php
							$total=0;
							$RE4=$conn->query("select * from funddetails where Budgettype=2 and Discipline=".$_POST["disci"]." and Accheads=".$row3['id']." and Equip_captype=".$row2['id']." and Equip_exptype=".$exptype." "); 
							while($row4=$RE4->fetch_assoc())
							{
							?>
								<tr>
									<td class="detail"><?php echo date("d-m-Y",strtotime($row4['EntryDate'])); ?></td>
									<td class="detail"><?php echo $row4['Particulars']; ?></td>
									<td class="detail"><?php echo $row4['Year']; ?></td>
									<td class="detail"><?php echo $row4['Indentor']; ?></td>
									<?php
										if($row4['IndentType']==1)
										{
											?>
											<td class="detail"><?php echo $row4['Indent_no']; ?></td>
											<td class="detail"><?php echo $row4['PO_no']; ?></td>
											<td class="detail"><?php echo moneyFormatIndia($row4['IndentAmt']); ?></td>
											<?php
										} 
										else if($row4['IndentType']==2)
										{
											?>
											<td class="detail" colspan="3">Direct Purchase</td>
											<?php
										}
										else if($row4['IndentType']==3)
										{
											?>
											<td class="detail" colspan="3">Direct Purchase(Through Advance)</td>
											<?php
										}
										else 
										{
											?>
											<td class="detail" colspan="3"><?php echo $row4['IndentVal']; ?></td>
											<?php
										}
									?>
									
									<td class="detail"><?php echo moneyFormatIndia($row4['Amount']); ?></td>
									<td class="detail"><?php echo $row4['Remarks']; ?></td>
								
								<form action="editdetails.php" method="post">
								<input type="hidden" name="sno" value="<?php echo $row4['SNo']; ?>"/>
								<td class="button"><input type="submit" value="EDIT"/></td>
								</form>
								<form>
								<td class="button"><input type="button" value="DELETE" onclick="confirmation(<?php echo $row1['SNo']; ?>)" /></td>
								</form>
							</tr>

							<?php
							}
					    } ?>

					<?php
				}
		}
	?>
	</table>
	<?php
}
?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

function gethead(val1,val2)
{
   $.ajax({
      type: 'post',
      url: 'gethead.php',
      data: {
        gethead: val1,
        disci1: val2
      },
      success: function (response) {
       document.getElementById("disci").innerHTML=response; 
     }
   });
}
</script>

<p class="logout"><a href="logout.php">LOGOUT</a></p>
<h2 class="choose1">CHOOSE</h2>
<form action="adminedit.php" method="post">
<select class="type1" name="type" id="type" onchange="gethead(this.value,0)">
<option value=0>Select The Budget Type</option> 
<option value=1>Recurring Budget</option>
<option value=2>Equipment Budget</option>
</select>
<select class="disci1" name="disci" id="disci">
  <option value=0>Select Head</option>
 </select>
 <input name="submit" class="submit1" src="images/submit.png" type="image">
 </form>
 <script type="text/javascript">
  <?php if(isset($_POST["type"]) && $_POST["type"]!=0) {?>document.getElementById('type').value = "<?php echo $_POST["type"];?>"; gethead(<?php echo $_POST["type"]; ?>,<?php echo $_POST["disci"];?>); <?php } ?>
</script>