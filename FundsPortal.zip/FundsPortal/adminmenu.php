<?php
session_start(); 
include("header.php"); 
include("session.php");
include("connection.php");
?>
<p class="logout"><a href="logout.php">LOGOUT</a></p>
<h2 class="adminmenu">ADMIN MENU</h2>
<a href="adminadd.php"><img class="add" src="images/detailsadd.ico"></img></a>
<a href="adminedit.php"><img class="edit" src="images/detailsedit.png"></img></a>
<a href="adminview.php"><img class="view" src="images/detailsview.gif"></img></a>
<a href="adminacc.php"><img class="acc" src="images/adminacc..ico"></img></a>
<a href="adminest.php"><img class="est" src="images/adminest.png"></img></a>

<p class="add">ADD DETAILS</p>
<p class="edit">EDIT DETAILS</p>
<p class="view">VIEW DETAILS</p>
<p class="acc">MANAGE USERS</p>
<p class="est">UPDATE ESTIMATE</p>